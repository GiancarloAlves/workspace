# Processo de atualização de Pedido de Venda

Este exemplo demonstra um fluxo de atualização de pedido de venda no Protheus, onde o usuário informa o pedido do protheus, é carregado os dados do pedido e os produtos. Após a alteração de quantidade e preços, o pedido passa por uma etapa de aprovação e é realizado a integração.

Também demonstra como preencher a data atual e o código da solicitação em um campo de formulário, como utilizar um template customizado de email para acompanhamento da solicitação e como usar o mecanismo de atribuição customizado.

## Pré-requisitos
Neste exemplo, usamos como servidor de integração um servidor **Protheus**. Em nossos serviços, vamos usar o ip como **protheus**. Você terá que substituir pelo ip do protheus.

## Configuração do ambiente

Acessar o fluig como usuário administrador, abrir o painel de controle e selecionar a opção Template de emails. Na página de templates, clicar em adicionar. Usar o código **tpl_atualizacao_pedido** (ou se usar outro nome, editar o script workflow/scripts/atualizacao_pedido_venda.constantes.js) e inserir arquivo templates/tpl_atualizacao_pedido.html. Crie o template para todos os idiomas para evitar problemas de configurações de idioma do usuário.

Acessar o fluig como usuário administrador, abrir o painel de controle e selecionar a opção Grupos. Na página de templates, clicar em adicionar. Inserir o grupo **aprovadores_1_protheus** e incluir os usuários responsáveis por aprovar a alteração do pedido.

Acessar o fluig como usuário administrador, abrir o painel de controle e selecionar a opção Serviços. Na página de serviços, clicar em novo serviço. Serão 4 serviços do tipo **SOAP**:

 * **PROTHEUS_MTSELLERSALESORDER**, que é o **Serviço de consulta e atualização das informações de pedido de venda** e URL http://protheus:1010/MTSELLERSALESORDER.apw?WSDL

 * **PROTHEUS_MTCUSTOMER**, que é o **Serviço de consulta de clientes** e URL http://protheus:1010/MTCUSTOMER.apw?WSDL

 * **PROTHEUS_MTPRODUCT**, que é o **Serviço de consulta de produtos** e URL http://protheus:1010/MTPRODUCT.apw?WSDL

 * **PROTHEUS_MTPAYMENTPLAN**, que é o **Serviço de consulta de condição de pagamento** e URL http://protheus:1010/MTPAYMENTPLAN.apw?WSDL


Com os serviços devidamente criados, cadastre os datasets. São 6 no total, sendo 3 do tipo simples, que devem ser cadastrados diretamente no fluig.

Acessar o fluig como usuário administrador, abrir o painel de controle e selecionar a opção Datasets. Na página de datasets, clicar em novo dataset e seleciona e opção simples.

**protheus_consulta_pedido_venda** que é o **Protheus - Consulta pedido de venda**, que usa o serviço **PROTHEUS_MTSELLERSALESORDER** e a operação **getsalesorder**. Informe os parâmetros:
 * **usercode**, atribuição pelo valor *MSALPHA*
 * **sellercode**, atribuição pelo valor em branco
 * **orderid**, atribuição pelo valor *000001* (esse valor enviado pelo formulário com o código do pedido informado por lá, mas preencher aqui permite que você consulte os dados pela web pra verificar o dataset)
 * **queryaddwhere**, atribuição vai ser nulo.


**protheus_consulta_produtos** que é o **Protheus - Consulta produtos**, que usa o serviço **PROTHEUS_MTPRODUCT** e a operação **getcatalog**. Informe os parâmetros:
 * **usercode**, atribuição pelo valor *MSALPHA*
 * **descriptionlike**, atribuição pelo valor *%*
 * **indexkey**, atribuição pelo valor *B1_DESC*
 * e os outros campos com atribuição nulo.


**protheus_consulta_condicao_pagamento** que é o **Protheus - Consulta condição de pagamento**, que usa o serviço **PROTHEUS_MTPAYMENTPLAN** e a operação **brwpaymentplan**. Informe os parâmetros:
 * **pagelen**, atribuição pelo valor *50*l
 * **pagefirst**, atribuição pelo valor *1*l
 * **queryaddwhere**, atribuição pelo valor em branco


E pelo eclipse exportar os outros datasets:
 * protheus_atualiza_pedido_venda,
 * protheus_consulta_pedido_venda_retorno_modificado,
 * protheus_consulta_cliente

No eclipse, Exportar o processo e o formulário de atualização de pedido de venda.


## Resultados esperados
O usuário irá preencher o formulário informando, obrigatoriamente, o id do pedido. Ao preencher o id, vai preencher a condição de pagamento, código e razão social do cliente e buscar os itens do pedido. O usuário pode modificar a quantidade e o valor unitário, o que vai recalcular o valor total da linha do pedido e, ao alterar a quantidade, o campo "Valor total novo" no topo dos itens.

Ao movimentar para a atividade seguinte (Aprovar alteração pedido), um usuário do grupo aprovadores_1_protheus deve assumir a tarefa. Ao abrir para movimentar, os campos de número de solicitação, data e solicitante estarão preenchidos. E a data atual e o nome do usuário atual será preenchido no final do formulário em "Aprovação".

Ao aprovar, o processo vai se conectar com o servidor e finalizar a solicitação.

Se reprovar, a solicitação vai ser finalizada.

## FAQ
#### Ao tentar criar o serviço, retornou a mensagem: "Erro na criação do serviço: Falha ao criar um registro"
O servidor não consegue encontrar a URL informada. Confira se o ip é referente ao servidor do protheus e se o servidor do fluig consegue acessar a url. Para isso, você pode tentar acessar pelo navegador do servidor a url informada e verificar se retorna um xml

#### Ao informar o id do pedido não carrega a condição de pagamento
Confira se você cadastrou corretamente o serviço PROTHEUS_MTPAYMENTPLAN e o dataset  

#### Ao informar o id do pedido, retornou a mensagem: "Não foi possível consultar a condição de pagamento java.lang.IllegalArgumentException: argument type mismatch"
Você está usando uma versão desatualizada do fluig. Atualize seu fluig.
