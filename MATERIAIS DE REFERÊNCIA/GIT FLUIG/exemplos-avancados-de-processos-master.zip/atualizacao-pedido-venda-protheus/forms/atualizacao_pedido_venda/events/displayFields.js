function displayFields(form,customHTML){
	// Mantém a visualização de campos do formulário igual, tanto para o modo modificação quanto visualização
	form.setShowDisabledFields(true);

	//Remove o botão padrão Fluig de impressão do formulário
	form.setHidePrintLink(true);

	// getValue("WKNumState"); -> Número da atividade atual de acordo com o diagrama
	var numeroAtividadeAtual = getValue("WKNumState");

	/*
	* form.getFormMode();
	* ADD - Momento inicial do formulário antes de iniciar e/ou salvar o processo
	* MOD - Momento a qual os campos estão editavéis para o usuário modificar após iniciar e/ou salvar o processo
	* VIEW - Modo de visualização do formulário
	*/
	var modoDeVisualizacaoDoFormulario = form.getFormMode();

	// getValue("WKUser"); ->  Retorno o código do usuário logado
	var codigoSolicitante = getValue("WKUser");

	// Obtém objeto com dados do usuário atual via uso da SDK, representada pelo objeto fluigAPI
	var usuarioCorrente = fluigAPI.getUserService().getCurrent();

	//Só altere, ou carregue, campos se não estiver em modo visualização
	if (modoDeVisualizacaoDoFormulario != "VIEW") {
		//Antes do processo ser iniciado ou salvo o número da primera ativade é 0
		if (numeroAtividadeAtual == Atividades.ZERO || numeroAtividadeAtual == Atividades.INICIO) {
			form.setValue("codigoSolicitante", usuarioCorrente.getCode());
			form.setValue("nomeSolicitante", usuarioCorrente.getFullName());
			form.setValue("dataSolicitacao", retornaDataAtual());

		} else if (numeroAtividadeAtual == Atividades.APROVAR_ALTERACAO) {
			form.setValue("codigoAprovador", usuarioCorrente.getCode());
			form.setValue("nomeAprovador", usuarioCorrente.getFullName());
			form.setValue("dataAprovacao", retornaDataAtual());
		}
	}

	// Exemplo de injeção de javascript pelo evento de formulário displayFields
	customHTML.append("<script type='text/javascript'>");
	customHTML.append("var modoDeVisualizacaoDoFormulario = '" + modoDeVisualizacaoDoFormulario + "';");
	customHTML.append("var numeroAtividadeAtual = " + numeroAtividadeAtual + ";");
	customHTML.append("var codigoSolicitante = '" + codigoSolicitante + "';");
	customHTML.append("</script>");
}

/**
* Função para retornar a data atual
* @returns data atual
*/
function retornaDataAtual() {
	return (new java.text.SimpleDateFormat('dd/MM/yyyy')).format(new Date());
}
