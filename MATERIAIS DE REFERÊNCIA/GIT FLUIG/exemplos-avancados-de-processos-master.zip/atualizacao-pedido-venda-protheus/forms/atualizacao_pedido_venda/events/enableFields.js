function enableFields(form) {
  //Campos que sempre são bloqueados independente da atividade
  form.setEnabled("codigoSolicitante", false);
  form.setEnabled("nomeSolicitante", false);
  form.setEnabled("codigoSolicitacao", false);
  form.setEnabled("dataSolicitacao", false);
  form.setEnabled("codigoAprovador", false);
  form.setEnabled("nomeAprovador", false);
  form.setEnabled("dataAprovacao", false);

  //Painel do formulário visível apenas depois de certo momento do formulário
  form.setVisibleById("painelAprovacao", false);

  // Número da atividade atual de acordo com o diagrama
  var numeroAtividadeAtual = getValue("WKNumState");

  //Condição exibir painel se está ou já passou em dada atividade
  if (numeroAtividadeAtual == Atividades.APROVAR_ALTERACAO || form.getValue("dataAprovacao") != "") {
    form.setVisibleById("painelAprovacao", true);
    form.setEnabled("idPedido", false);

    /*
    * Cada linha adicionada numa tabela Pai x Filho tem um indice
    * O campos dessa linha <tr> terão adicionados aos seus atributos name três underlines. Ex.: ___1 ; ___2 etc.
    * O número após o _ é o indice. Com esse valor é possível iterar na lista de campos e obter e validar o valor dos campos em cada linha
    */
    var indicePaiFilhoItens = form.getChildrenIndexes("tbItensPedido");
    for (var i = 0; i < indicePaiFilhoItens.length; i++) {
      //Indice naquela posição da lista
      var indice = indicePaiFilhoItens[i];
      form.setEnabled("numeroItem___"+indice, false);
      form.setEnabled("produto___"+indice, false);
      form.setEnabled("quantidade___"+indice, false);
      form.setEnabled("precoUnitario___"+indice, false);
      form.setEnabled("valorTotal___"+indice, false);
    }
  }

  /*
  * form.getFormMode();
  * ADD - Momento inicial do formulário antes de iniciar e/ou salvar o processo
  * MOD - Momento a qual os campos estão editavéis para o usuário modificar após iniciar e/ou salvar o processo
  * VIEW - Modo de visualização do formulário
  */
  var modoDeVisualizacaoDoFormulario = form.getFormMode();

  // Se for modo visualização ou atividade diferente da atividade inicial o pai x filho de itens e o campo de id do pedido devem ficar bloqueados
  if (modoDeVisualizacaoDoFormulario == "VIEW" || (numeroAtividadeAtual != Atividades.ZERO && numeroAtividadeAtual != Atividades.INICIO)) {
    enableItensPedido(form, false);
    form.setEnabled("idPedido", false);
  }
}

function enableItensPedido(form, enable){
  /*
  * Cada linha adicionada numa tabela Pai x Filho tem um indice
  * O campos dessa linha <tr> terão adicionados aos seus atributos name três underlines. Ex.: ___1 ; ___2 etc.
  * O número após o _ é o indice. Com esse valor é possível iterar na lista de campos e obter e validar o valor dos campos em cada linha
  */
  var indicePaiFilhoItens = form.getChildrenIndexes("tbItensPedido");

  //Se houver ao menos um registro de pai x filho
  if (indicePaiFilhoItens.length > 0) {

    //Faz a iteração nas linhas do pai x filho
    for (var i = 0; i < indicePaiFilhoItens.length; i++) {
      
      //Bloqueia ou desbloqueia os campos editáveis conforme parametro enable
      var indice = indicePaiFilhoItens[i];
      form.setEnabled("codigoProduto___"+indice, enable);
      form.setEnabled("quantidade___"+indice, enable);
      form.setEnabled("precoUnitario___"+indice, enable);
    }
  }
}
