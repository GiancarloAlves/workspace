function validateForm(form){
	// getValue("WKNumState"); -> Número da atividade atual de acordo com o diagrama
  var numeroAtividadeAtual = getValue("WKNumState");

  // getValue("WKNextState"); -> Número da atividade seguinte de acordo com o diagrama
  var numeroProximaAtividade = getValue("WKNextState");

  // getValue("WKCompletTask")=="true" -> Valida se a atividade foi realmente concluída ou apenas salva
	var atividadeConcluida = (getValue("WKCompletTask")=="true");

  // Se a atividade foi apenas salva ou atividade destino for igual atividade atual, não aplica validações
  if (!atividadeConcluida || numeroAtividadeAtual == numeroProximaAtividade) {
    return;
  }

  // Criado variavel para acumular as mensagens de erro e exibir de uma única vez
  var mensagemDeErro = "";

	// condição para validar o preenchimento do campo 'Descrição' nas atividades relevantes (0,4,5, e 7) utilizado .trim() para remover possíveis espaços.
  // Ex.: "   ", Resultado com .trim() : ""
  if (numeroAtividadeAtual == Atividades.INICIO || numeroAtividadeAtual == Atividades.ZERO) {
		if (valorEmBranco(form.getValue("idPedido"))) {
			mensagemDeErro +=" O campo 'Pedido' não foi preenchido;\n";
		}

		/*
    * Cada linha adicionada numa tabela Pai x Filho tem um indice
    * O campos dessa linha <tr> terão adicionados aos seus atributos name três underlines. Ex.: ___1 ; ___2 etc.
    * O número após o _ é o indice. Com esse valor é possível iterar na lista de campos e obter e validar o valor dos campos em cada linha
    */
    var indicePaiFilhoItens = form.getChildrenIndexes("tbItensPedido");

		//Se não houver um registro de pai x filho, vai armazenar o erro para exibir
		if (indicePaiFilhoItens.length == 0) {
			mensagemDeErro += 'O pedido deve ter ao menos 1 item. \n';
		} else {
			//Faz a iteração nas linhas do pai x filho
			for (var i = 0; i < indicePaiFilhoItens.length; i++) {

				//Variável auxiliar para o usuario saber qual a linha conforme exibido em tela
				var linha = i + 1;

				//Indice naquela posição da lista
				var indice = indicePaiFilhoItens[i];

				if(valorEmBranco(form.getValue('codigoProduto___' + indice))) {
					mensagemDeErro += 'Campo "Produto" é obrigatório (linha ' + linha + ' tabela Itens). \n';
				}

				if(valorEmBranco(form.getValue('quantidade___' + indice))) {
					mensagemDeErro += 'Campo "Quantidade" é obrigatório (linha ' + linha + ' tabela Itens). \n';
				} else if(parseFloat(form.getValue('quantidade___' + indice)) <= 0){
					mensagemDeErro += 'Campo "Quantidade" deve ter valor superior a Zero (0) (linha ' + linha + ' tabela Itens). \n';
				}

				if(valorEmBranco(form.getValue('precoUnitario___' + indice))) {
					mensagemDeErro += 'Campo "Preço unitário" é obrigatório (linha ' + linha + ' tabela Plano Itens). \n';
				} else if(parseFloat(form.getValue('precoUnitario___' + indice)) <= 0){
					mensagemDeErro += 'Campo "Preço unitário" deve ter valor superior a Zero (0) (linha ' + linha + ' tabela Itens). \n';
				}

			}
		}
	}

	if (mensagemDeErro != "") {
		throw mensagemDeErro;
	}
}

/**
 * Função valorEmBranco é um facilitador que evita você precisar repetir a condição completa  verificando se o valor está undefined, null ou se está vazio
 * @param value valor a ser testado
 * @returns verdadeiro caso seja null, undefined ou após a função trim() estiver vazio ou falso se tiver conteúdo
 */
function valorEmBranco(value) {
	return (value == null || value == undefined || value.trim() == "");
}
