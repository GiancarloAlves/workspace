var Datasets = {
	CONSULTA_PEDIDO: "protheus_consulta_pedido_venda_retorno_modificado",
	CONSULTA_CLIENTE: "protheus_consulta_cliente",
	CONSULTA_CONDICAO_PAGAMENTO: "protheus_consulta_condicao_pagamento",
	CONSULTA_ITEM: "protheus_consulta_pedido_venda_retorno_modificado"
}

/**
* Função para formatar valor (moeda)
*/
var formatter = new Intl.NumberFormat('pt-BR', {
	minimumFractionDigits: 2,
});

var loading = FLUIGC.loading(window);

$(document).ready(function() {
	init();
});

/**
* Função para ser chamada assim que a página estiver carregada.
*/
function init(){
	$("#idPedido").change(function() {
		var idPedido = $("#idPedido").val();
		if (idPedido != "" && idPedido != null && idPedido != undefined) {
			loading.show();

			/**
			* Executando dataset para buscar os dados de um pedido
			*/
			var constraintPedido = new Array();
			constraintPedido.push(DatasetFactory.createConstraint("orderid", idPedido, idPedido, ConstraintType.MUST));
			constraintPedido.push(DatasetFactory.createConstraint("tipo", "SOHEADER", "SOHEADER", ConstraintType.MUST));

			DatasetFactory.getDataset(Datasets.CONSULTA_PEDIDO, null, constraintPedido, null,{
				success : (dataPedido) => {
					if (dataPedido !== null && dataPedido.values !== null && dataPedido.values.length > 0) {
						if (dataPedido.values[0].error != undefined) {
							limpaCamposPedido();

							FLUIGC.toast({
								message : "Não foi possível consultar o pedido \n\n" + dataPedido.values[0].error.split('Exception:')[1],
								type: "warning"
							});
							loading.hide();
						} else {
							buscaCliente(dataPedido.values[0].customercode);
							buscaCondicaoPagamento(dataPedido.values[0].paymentplancode);
							buscaItensPedido(idPedido);
							setTimeout(function(){ loading.hide(); }, 3000);
						}
					} else {
						limpaCamposPedido();
					}
				},  error : (err) => {
					limpaCamposPedido();
					FLUIGC.toast({
						message : "Não foi possível consultar o pedido \n",
						type: "warning"
					});
					loading.hide();
				}
			});
		} else {
			limpaCamposPedido();
		}
	});
}

/**
* Função para limpar os campos referente ao pedido caso alguma integração retorne erro.
*/
function limpaCamposPedido(){
	$("#dataRegistro").val('');
	$("#condicaoPagamento").val('');
	$("#codigoCliente").val('');
	$("#nomeCliente").val('');
	$("#idPedido").val('');
	$("#valorTotalOriginal").val('');
	$("#valorTotalNovo").val('');
	$(".remove-linha").each(function(){
		fnWdkRemoveChild(this);
	})
}

/**
* Função padrão setSelectedZoomItem para identificar qual campo zoom acaba de ser preenchido,
* recebe como parametro um objeto com o nome, id e outros valores do campo zoom.
* @param {*} selectedItem
*/
function setSelectedZoomItem(selectedItem) {
	var index = selectedItem.inputId.split("produto___")[1];
	if (selectedItem.inputId == "produto___"+index) {
		$("#codigoProduto___"+index).val(selectedItem.pRODUCTCODE);
	}
}

/**
* Função padrão removedZoomItem para identificar qual campo zoom acaba de ter o valor removido.
* Recebe como parametro um objeto com o nome, id e outros valores do campo zoom.
* @param {*} selectedItem
*/
function removedZoomItem(selectedItem) {
	var index = selectedItem.inputId.split("produto___")[1];
	if(selectedItem.inputId == "produto___"+index){
		$("#codigoProduto___"+index).val('');
		$("#quantidade___"+index).val('');
		$("#precoUnitario___"+index).val('');
		$("#valorTotal___"+index).val('');
		calcularValorTotalDoPedido("valorCalculado");
	}
}

/**
* Função para calcular o valor total do pedido, recebe como parametro o tipo que pode ser valorRecebido ou valorCalculado.
* No caso de valor recebido a função cálcula e preenche o campo de valor total do pedido,
* já no caso de valor calculado a função calcula e preenche o novo valor total do pedido.
* @param {*} tipo
*/
function calcularValorTotalDoPedido(tipo) {
	var tabela = document.getElementById("tbItensPedido");
	if (tabela != null) {
		var itens = tabela.getElementsByTagName("input");

		var total = 0;

		for (var i = 0; i < itens.length; i++) {
			if (itens[i].id != null && itens[i].id.indexOf("valorTotal___") != -1) {
				if (itens[i].value != "") {
					total += converterFormatterParaFloat(itens[i].value);
				}
			}
		}

		let valorTotal = formatter.format(total);
		if (tipo == "valorRecebido") {
			$("#valorTotalOriginal").val(valorTotal);
		} else if (tipo == "valorCalculado") {
			$("#valorTotalNovo").val(valorTotal);
		}

	}
}

/**
* Função para executar o dataset de busca de cliente. Recebe como parametro o código do cliente retornado no pedido.
* @param {*} codigoCliente
*/
function buscaCliente(codigoCliente) {
	var constraintCliente = new Array();
	constraintCliente.push(DatasetFactory.createConstraint("CUSTOMERCODE", codigoCliente, codigoCliente, ConstraintType.MUST))
	DatasetFactory.getDataset(Datasets.CONSULTA_CLIENTE, null, constraintCliente, null,{
		success : (dataCliente) => {

			if (dataCliente == null || dataCliente == undefined || dataCliente.values == null || dataCliente.values == undefined) {
				console.log("Dataset de consulta de cliente retornou um valor em branco");
				return;
			} else if (dataCliente.values.length == 0) {
				console.log("Dataset de consulta de cliente não encontrou nenhum registro");
				return;
			}

			if (dataCliente.values[0].error != undefined) {
				limpaCamposPedido();
				FLUIGC.toast({
					message : "Não foi possível consultar os dados do cliente \n\n"+dataCliente.values[0].error,
					type: "warning"
				});
				loading.hide();
			} else {
				$("#codigoCliente").val(dataCliente.values[0].CUSTOMERCODE);
				$("#nomeCliente").val(dataCliente.values[0].NAME);
			}

		}, error : (err) => {
			limpaCamposPedido();
			FLUIGC.toast({
				message : "Não foi possível consultar os dados do cliente \n",
				type: "warning"
			});
			loading.hide();
		}
	});
}

/**
* Função para executar o dataset de busca de condição de pagamento. Recebe como parametro o código da condição de pagamento.
* @param {*} codigoCondicao
*/
function buscaCondicaoPagamento(codigoCondicao){
	var constraintCondicaoPagamento = new Array();
	constraintCondicaoPagamento.push(DatasetFactory.createConstraint("paymentplancode", codigoCondicao, codigoCondicao, ConstraintType.MUST));

	DatasetFactory.getDataset(Datasets.CONSULTA_CONDICAO_PAGAMENTO, null, constraintCondicaoPagamento, null,{
		success : (dataCondicaoPagamento) => {
			if (dataCondicaoPagamento == null || dataCondicaoPagamento == undefined || dataCondicaoPagamento.values == null || dataCondicaoPagamento.values == undefined) {
				console.log("Dataset de consulta de condição de pagamento retornou um valor em branco");
				return;
			} else if (dataCondicaoPagamento.values.length == 0) {
				console.log("Dataset de consulta de condição de pagamento não encontrou nenhum registro");
				return;
			}

			if (dataCondicaoPagamento.values[0].error != undefined) {
				limpaCamposPedido();
				FLUIGC.toast({
					message : "Não foi possível consultar a condição de pagamento \n\n"+dataCondicaoPagamento.values[0].error,
					type: "warning"
				});
				loading.hide();
			} else {
				$("#condicaoPagamento").val(dataCondicaoPagamento.values[0].dESCRIPTIONPAYMENTPLAN);
			}
		}, error : (err) => {
			limpaCamposPedido();
			FLUIGC.toast({
				message : "Não foi possível consultar a condição de pagamento \n",
				type: "warning"
			});
			loading.hide();
		}
	});
}

/**
* Função para executar o dataset que busca os itens do pedido e monta a tabela pai e filho de itens.
* Recebe como parametro o identificador do pedido informado pelo usuário.
* @param {*} idPedido
*/
function buscaItensPedido(idPedido){
	var constraintItens = new Array();
	constraintItens.push(DatasetFactory.createConstraint("orderid", idPedido, idPedido, ConstraintType.MUST));
	constraintItens.push(DatasetFactory.createConstraint("tipo", "SOITEM", "SOITEM", ConstraintType.MUST));

	DatasetFactory.getDataset(Datasets.CONSULTA_ITEM, null, constraintItens, null,{
		success : (dataItens) => {
			if (dataItens == null || dataItens == undefined || dataItens.values == null || dataItens.values == undefined) {
				console.log("Dataset de consulta de itens do pedido retornou um valor em branco");
				return;
			} else if (dataItens.values.length == 0) {
				console.log("Dataset de consulta de itens do pedido não encontrou nenhum registro");
				return;
			}

			if (dataItens.values[0].error != undefined) {
				limpaCamposPedido();
				FLUIGC.toast({message : "Não foi possível consultar os itens do pedido \n\n"+dataItens.values[0].error, type: "warning"});
				loading.hide();

				return;
			}
			var itens = dataItens.values;
			if (itens.length > 0) {
				let index = wdkAddChild('tbItensPedido');
				for (var i=1; i < itens.length; i++) {
					wdkAddChild('tbItensPedido')
				}

				//Função que inicializa os zooms na linha de pai x filho. Essa função é do próprio fluig carregada em forms.js
				hasZoom();

				// espera um segundo até que varra todos os campos criados
				setTimeout(function() {
					for (var i=0; i < itens.length; i++) {
						let item = itens[i];

						let _index = index;

						$("#numeroItem___"+index).val(item.posequence);
						$("#codigoProduto___"+index).val(item.productid);
						window["produto___"+index].setValue(item.productdescription);
						$("#quantidade___"+index).val(item.quantity);
						$("#precoUnitario___"+index).val(formatter.format(item.netunitprice));
						$("#valorTotal___"+index).val(formatter.format(item.nettotal));

						// Adicionado mascara aos campos de quantidade e preço unitario
						$("#quantidade___"+index).mask('#.###.###.##0,0000', {reverse: true});
						$("#precoUnitario___"+index).mask('#.###.###.##0,00', {reverse: true});

						$("#quantidade___"+index +", #precoUnitario___"+index).change(function(element, event) {
							onChangeQuantidadeOrPreco(_index);
						});
						index++;
					}

					calcularValorTotalDoPedido("valorRecebido");
				}, 1000);

				loading.hide();
			}
		}, error : (err) => {
			limpaCamposPedido();
			FLUIGC.toast({message : "Não foi possível consultar a condição de pagamento \n", type: "warning"});
			loading.hide();
		}
	});
}

isValorValido = (value) => value != null && value != undefined && value != '' && !isNaN(parseFloat(converterParaPadraoAmericano(value)));

// Remove os '.' usados como separador de milhar e substitui o separador de decimais (',') por '.' que é como o float entende
converterParaPadraoAmericano = (value) => value.replace(/\./g, "").replace(",",".");

// Remove os '.' usados como separador de milhar e substitui o separador de decimais (',') por '.' que é como o float entende.
// Depois, multiplca por 100 (ou seja, pega as duas casas decimais), remove todas as outras casas decimais, e devolve dividindo por dois (ou seja, voltando as duas casas decimais)
converterFormatterParaFloat = (value) => Math.trunc(parseFloat(converterParaPadraoAmericano(value))*100)/100;

onChangeQuantidadeOrPreco = (index) => {
	var quantidade = $("#quantidade___"+index).val();
	var precoUnitario = $("#precoUnitario___"+index).val();

	if (isValorValido(quantidade) && isValorValido(precoUnitario)) {
		var valorTotalLinha = formatter.format(parseFloat(converterFormatterParaFloat(quantidade)*converterFormatterParaFloat(precoUnitario)));
		$("#valorTotal___"+index).val(valorTotalLinha);

		calcularValorTotalDoPedido("valorCalculado");
	} else {
		$("#valorTotal___"+index).val("0");
		calcularValorTotalDoPedido("valorCalculado");
	}
}
