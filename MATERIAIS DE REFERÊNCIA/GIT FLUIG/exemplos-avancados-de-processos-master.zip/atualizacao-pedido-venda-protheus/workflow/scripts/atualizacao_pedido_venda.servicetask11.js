function servicetask11(attempt, message) {
	// Atividade de serviço para atualizar o pedido de venda no Protheus.
	// O primeiro passo é consultar a ordem de venda no protheus para obter todos os dados
	var pedidoDeVenda = hAPI.getCardValue("idPedido");
	var constraints = [
		DatasetFactory.createConstraint("orderid", pedidoDeVenda, "", ConstraintType.MUST)
	];
	var datasetPedidosVenda = DatasetFactory.getDataset("protheus_consulta_pedido_venda", [], constraints, []);

	// Se a consulta deu certo (não é igual a null) e se a consulta retornou quantidade de registros maior que zero
	if(datasetPedidosVenda && datasetPedidosVenda.rowsCount > 0){
		// A consulta de pedido retorna sempre apenas um registro por isso é descessária a iteração, e usamos direto o 0 (zero) como indíce
		// A consulta retorna dois campos com texto com JSON, sOHEADER e sOITEM sendo necessário converte-los em objeto para podermos manipular os dados
		var sOHEADER = JSON.parse(datasetPedidosVenda.getValue(0,"sOHEADER"));
		var sOITEM = JSON.parse(datasetPedidosVenda.getValue(0,"sOITEM"));

		// Recupera a lista de itens do formulário para então iterar nessa lista atualizando os valores dos campos do objeto
		// de pedido obtidos do protheus com os dados preenchidos pelo usuário no formulário
		var indicePaiFilhoItens = hAPI.getChildrenIndexes("tbItensPedido");
		
		for (var i = 0; i < indicePaiFilhoItens.length; i++) {
			var indice = indicePaiFilhoItens[i];

			var codigoProduto = hAPI.getCardValue('codigoProduto___' + indice);
			var descricaoProduto = hAPI.getCardValue('produto___' + indice);
			var quantidade = hAPI.getCardValue('quantidade___' + indice);
			var precoUnitario = hAPI.getCardValue('precoUnitario___' + indice);
			var valorTotal = hAPI.getCardValue('valorTotal___' + indice);

			/**
			* Carrega a identificação para LINPOS, para permitir alterar o produto no item
			* LINPOS (orderitem) := C6_ITEM+C6_PRODUTO
			* C6_ITEM => posequence
			* C6_PRODUTO => productid antes da alteração
			**/
			var sequencia = ""+sOITEM.salesorderitemview[i].posequence;
			var codigoProdutoOriginal = ""+sOITEM.salesorderitemview[i].productid;
			var orderitem = sequencia+codigoProdutoOriginal;

			sOITEM.salesorderitemview[i].orderitem = orderitem;
			sOITEM.salesorderitemview[i].productid = codigoProduto;
			sOITEM.salesorderitemview[i].productdescription = descricaoProduto;
			sOITEM.salesorderitemview[i].quantity = preparaValor(quantidade);
			sOITEM.salesorderitemview[i].netunitprice = preparaValor(precoUnitario);
			sOITEM.salesorderitemview[i].nettotal = preparaValor(valorTotal);
		}

		// Itera em todos os campos do objeto com a lista de itens e remove espaços desnecessários dos valores
		for(var i in sOITEM.salesorderitemview){
			for(var j in sOITEM.salesorderitemview[i]){
				var value = sOITEM.salesorderitemview[i][j];
				
				if (typeof value === "string" && !valorEmBranco(value)) {
					sOITEM.salesorderitemview[i][j] = value.trim();
				}
			}
		}

		var salesorder = {
			"sOHEADER": sOHEADER
			, "sOITEM": sOITEM.salesorderitemview
		}

		// Imprime as informações retornadas pelo serviço. Útil para encontrar problemas na integração mas pode gerar bastante log.
		log.info("atualizacao_pedido_venda.servicetask11 - salesorder");
		log.dir(salesorder);

		// Uma vez obtido os dados do pedido de venda e esses tendo sido tratados e os valores dos respectivos
		// campos de itens tendo sido atualizados acionamos o dataset e integração que executa a atualização no Protheus
		var paramPedido = [
			DatasetFactory.createConstraint("salesorder", JSONUtil.toJSON(salesorder), "", ConstraintType.MUST)
		];
		var resultadoAtualizacao = DatasetFactory.getDataset("protheus_atualiza_pedido_venda", [], paramPedido, []);
		if (resultadoAtualizacao && resultadoAtualizacao.rowsCount > 0) {
			var erro = resultadoAtualizacao.getValue(0, "error");

			// Verifica se a atualização de pedidos retornou o campo erro e se este está preenchido
			if (valorEmBranco(erro)) {
				var condicaoPagamento = hAPI.getCardValue("condicaoPagamento");
				var nomeSolicitante = hAPI.getCardValue("nomeSolicitante");
				var nomeCliente = hAPI.getCardValue("nomeCliente");
				var idPedido = hAPI.getCardValue("idPedido");
				var valorTotalOriginal = hAPI.getCardValue("valorTotalOriginal");
				var valorTotalNovo = hAPI.getCardValue("valorTotalNovo");

				var destinatarios = new java.util.ArrayList();

				// Obtém objeto com dados do usuário solicitante via uso da SDK, representada pelo objeto fluigAPI
				var usuario = fluigAPI.getUserService().findByUserCode(hAPI.getCardValue('codigoSolicitante'));

				//Adiciona email do usuário na lista de destinatários
				destinatarios.add(usuario.getEmail());

				enviarEmail(condicaoPagamento, nomeCliente, nomeSolicitante, idPedido, valorTotalOriginal, valorTotalNovo, destinatarios);
			} else {
				//Se o erro está preenchido, lança a exceção para tratamento
				log.error("atualizacao_pedido_venda.servicetask11  - protheus_atualiza_pedido_venda - erro obtido: " + erro);
				throw erro;
			}
		}
	} else {
		throw "Não foi possível obter os dados do pedido de venda (" + pedidoDeVenda + ") no Protheus";
	}
}

/**
 * Função valorEmBranco é um facilitador que evita você precisar repetir a condição completa  verificando se o valor está undefined, null ou se está vazio
 * @param value valor a ser testado
 * @returns verdadeiro caso seja null, undefined ou após a função trim() estiver vazio ou falso se tiver conteúdo
 */
function valorEmBranco(value) {
	return (value == null || value == undefined || value.trim() == "");
}

/**
* Recebe valor string com "." e "," e troca para padrão esperado.
* Substitui "." por vazio. Exemplo: 1.100,00 -> 1100,00
* @param valor
* @returns valorTratado
*/
function preparaValor(valor){
	return valor == null ? "" : (""+valor).replace(/\./g, "");
}
