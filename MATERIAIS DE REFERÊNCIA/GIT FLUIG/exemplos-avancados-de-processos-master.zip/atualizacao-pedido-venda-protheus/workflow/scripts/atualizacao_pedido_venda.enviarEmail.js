function enviarEmail(condicaoPagamento, nomeCliente, nomeSolicitante, idPedido, valorTotalOriginal, valorTotalNovo, destinatarios){
	log.info("atualizacao_pedido_venda.enviarEmail - condicaoPagamento: " + condicaoPagamento
		+ " - nomeCliente: " + nomeCliente + " - idPedido: " + idPedido
		+ " - valorTotalOriginal: " + valorTotalOriginal
		+ " - valorTotalNovo: " + valorTotalNovo);
		
	try {
		// Cria mapa de parametros para enviar ao template de e-mail
		var parametros = new java.util.HashMap();

		// Operação padrão para recuperar o código da empresa Fluig utilizada como um dos parametros de envio
		var codigoEmpresa = ""+getValue("WKCompany");

		// método da api fluig para recuperar a url do servidor utilizada como um dos parametros de envio
		var serverUrl = fluigAPI.getPageService().getServerURL();

		// Adiciona ao mapa de parametros todos os valores esperados pelo template de e-mail
		parametros.put("SERVER_URL", serverUrl);
		parametros.put("CODIGO_EMPRESA", codigoEmpresa);
		parametros.put("NOME_SOLICITANTE", nomeSolicitante);
		parametros.put("PEDIDO", idPedido);
		parametros.put("NOME_CLIENTE", nomeCliente);
		parametros.put("CONDICAO_PAGAMENTO", condicaoPagamento);
		parametros.put("VALOR_TOTAL_ORIGINAL", valorTotalOriginal);
		parametros.put("VALOR_TOTAL_ATUALIZADO", valorTotalNovo);

		// parametro padrao obrigatorio: assunto do e-mail
		parametros.put("subject", Email.Assunto + idPedido);

		// código da matricula do remetente do e-mail neste caso código do usuário logado no Fluig
		var remetente = getValue("WKUser");

		// código do template de e-mail customizado previamente desenvolvido e cadastrado no Fluig
		var codigoTemplate = Email.Template;

		// metodo padrao Fluig para envio de e-mail customizado
		notifier.notify(remetente, codigoTemplate, parametros, destinatarios, "text/html");

	} catch(e) {
		log.error(e);
		throw "Ocorreu erro no envio de e-mail para os grupos de atendimento: "+e;
	}
}
