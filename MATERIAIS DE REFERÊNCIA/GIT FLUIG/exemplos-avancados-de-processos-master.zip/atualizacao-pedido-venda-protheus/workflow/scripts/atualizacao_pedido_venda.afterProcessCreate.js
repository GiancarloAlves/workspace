function afterProcessCreate(processId){
	// Evento de processo afterProcessCreate é executado depois do processo ser criado (iniciado ou salvo) recebe como parametro processId que é o número da solicitação gerada
	hAPI.setCardValue("codigoSolicitacao", processId);
	hAPI.setCardValue("descricaoFicha", processId + " - Pedido: " + hAPI.getCardValue("idPedido"));
}
