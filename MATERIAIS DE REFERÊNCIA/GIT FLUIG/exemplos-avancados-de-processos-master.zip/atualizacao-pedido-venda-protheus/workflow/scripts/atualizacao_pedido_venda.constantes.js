var Email = {
	Template: "tpl_atualizacao_pedido", // código do template de e-mail customizado previamente desenvolvido e cadastrado no Fluig
	Assunto: "Atualização do pedido de venda: "
}