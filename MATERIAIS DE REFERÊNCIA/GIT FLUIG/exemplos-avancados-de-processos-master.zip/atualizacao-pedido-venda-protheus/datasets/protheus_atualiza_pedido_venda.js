/**
 * Esse dataset teve a versão inicial gerada via wizard de cadastro de datasets
 * sendo este, configurado para atualizar pedido, via serviço: PROTHEUS_MTSELLERSALESORDER
 * Devido algumas características, alguns tratamentos foram adicionados manualmente no código.
 * Para tal, o dataset foi importado e alterado no editor de código fonte (eclipse)
 * Uma vez alterado o dataset foi publicado, deixando de ser um dataset SIMPLES e
 * passando a ser considerado pela plataforma como AVANÇADO.
 *
 * As funções alteradas foram:
 * -fillUSERFIELD; fillSALESORDERHEADERVIEW; fillSALESORDERITEMVIEW e fillGENERICSTRUCT
 * 	O dataset de consulta da ordem no Protheus retorna os elementos internos todos
 * 	em caixa baixa (lowercase), gerando a não identificação dos parâmetros,
 * 	que fazia o fluig enviar os campos como nulos.
 * -fillBigInteger
 * 	Necessário instanciar um objeto java da classe Long
 * 	, para a correta conversão e passagem do parâmetro
 */
function createDataset(fields, constraints, sortFields) {
	try {
		return processResult(callService(fields, constraints, sortFields));
	} catch(e) {
		return processErrorResult(e, constraints);
	}
}

function callService(fields, constraints, sortFields) {
	var serviceData = data();
	var params = serviceData.inputValues;
	var assigns = serviceData.inputAssignments;

	verifyConstraints(serviceData.inputValues, constraints);

	var serviceHelper = ServiceManager.getService(serviceData.fluigService);
	var serviceLocator = serviceHelper.instantiate(serviceData.locatorClass);
	var service = serviceLocator.getMTSELLERSALESORDERSOAP();
	var response = service.putsalesorder(getParamValue(params.usercode, assigns.usercode), getParamValue(params.sellercode, assigns.sellercode),
		fillSALESORDERVIEW(serviceHelper, params.salesorder, assigns.salesorder));

	return response;
}

function defineStructure() {
		addColumn('response');
}

function onSync(lastSyncDate) {
	var serviceData = data();
	var synchronizedDataset = DatasetBuilder.newDataset();

	try {
		var resultDataset = processResult(callService());
		if (resultDataset != null) {
			var values = resultDataset.getValues();
			for (var i = 0; i < values.length; i++) {
				synchronizedDataset.addRow(values[i]);
			}
		}

	} catch(e) {
		log.info('Dataset synchronization error : ' + e.message);

	}
	return synchronizedDataset;
}

function verifyConstraints(params, constraints) {
	if (constraints != null) {
		for (var i = 0; i < constraints.length; i++) {
			try {
				params[constraints[i].fieldName] = JSON.parse(constraints[i].initialValue);
			} catch(e) {
				params[constraints[i].fieldName] = constraints[i].initialValue;
			}
		}
	}
}

function processResult(result) {
	var dataset = DatasetBuilder.newDataset();

	dataset.addColumn("response");
	dataset.addRow([result]);

	return dataset;
}

function processErrorResult(error, constraints) {
	var dataset = DatasetBuilder.newDataset();

	var params = data().inputValues;
	verifyConstraints(params, constraints);

	dataset.addColumn('error');
	dataset.addColumn('sellercode');
	dataset.addColumn('usercode');
	dataset.addColumn('salesorder');

	var sellercode = isPrimitive(params.sellercode) ? params.sellercode : JSONUtil.toJSON(params.sellercode);
	var usercode = isPrimitive(params.usercode) ? params.usercode : JSONUtil.toJSON(params.usercode);
	var salesorder = isPrimitive(params.salesorder) ? params.salesorder : JSONUtil.toJSON(params.salesorder);

	dataset.addRow([error.message, sellercode, usercode, salesorder]);

	return dataset;
}

function getParamValue(param, assignment) {
	if (assignment == 'VARIABLE') {
		return getValue(param);
	} else if (assignment == 'NULL') {
		return null;
	}
	return param;
}

function hasValue(value) {
	return value !== null && value !== undefined;
}

function isPrimitive(value) {
	return ((typeof value === 'string') || value.substring !== undefined) || typeof value === 'number' || typeof value === 'boolean' || typeof value === 'undefined';
}

function fillGENERICSTRUCT(serviceHelper, params, assigns) {
	if (params == null) {
		return null;
	}

	var result = serviceHelper.instantiate("br.com.microsiga.webservices.mtsellersalesorder.GENERICSTRUCT");

	var cODE = getParamValue(params.code, assigns.cODE);
	if (hasValue(cODE)) {
    result.setCODE(cODE);
  }

	var dESCRIPTION = getParamValue(params.description, assigns.dESCRIPTION);
	if (hasValue(dESCRIPTION)) {
    result.setDESCRIPTION(dESCRIPTION);
  }
  
	var vALUE = getParamValue(params.value, assigns.vALUE);
	if (hasValue(vALUE)) {
    result.setVALUE(vALUE);
  }

	return result;
}

function fillARRAYOFGENERICSTRUCT(serviceHelper, params, assigns) {
	if (params == null) {
		return null;
	}

	var result = serviceHelper.instantiate("br.com.microsiga.webservices.mtsellersalesorder.ARRAYOFGENERICSTRUCT");

	for (var i = 0; i < params.length; i++) {
		result.getGENERICSTRUCT().add(fillGENERICSTRUCT(serviceHelper, params[i], assigns[i]));
	}

	return result;
}

function fillBigInteger(serviceHelper, param, assign) {
	if (param == null) {
		return null;
	}
	//Valor do parâmetro precisa ser um Long para funcionar a conversão para BigInteger
	param = java.lang.Long.valueOf(param);

	var result = serviceHelper.executeStaticMethod("java.math.BigInteger", "valueOf", ["long"], [getParamValue(param, assign)]);

	return result;
}

function fillUSERFIELD(serviceHelper, params, assigns) {
	if (params == null) {
		return null;
	}

	var result = serviceHelper.instantiate("br.com.microsiga.webservices.mtsellersalesorder.USERFIELD");

  var uSERCOMBOBOX = getParamValue(params.usercombobox, assigns.uSERCOMBOBOX);
  if (hasValue(uSERCOMBOBOX)) {
  	result.setUSERCOMBOBOX(uSERCOMBOBOX);
  }

  var uSERF3 = getParamValue(params.userf3, assigns.uSERF3);
  if (hasValue(uSERF3)) {
  	result.setUSERF3(uSERF3);
  }

  var uSERNAME = getParamValue(params.username, assigns.uSERNAME);
  if (hasValue(uSERNAME)) {
  	result.setUSERNAME(uSERNAME);
  }

  var uSEROBLIG = getParamValue(params.useroblig, assigns.uSEROBLIG);
  if (hasValue(uSEROBLIG)) {
  	result.setUSEROBLIG(uSEROBLIG);
  }

  var uSERPICTURE = getParamValue(params.userpicture, assigns.uSERPICTURE);
  if (hasValue(uSERPICTURE)) {
  	result.setUSERPICTURE(uSERPICTURE);
  }

  var uSERTAG = getParamValue(params.usertag, assigns.uSERTAG);
  if (hasValue(uSERTAG)) {
  	result.setUSERTAG(uSERTAG);
  }

  var uSERTITLE = getParamValue(params.usertitle, assigns.uSERTITLE);
  if (hasValue(uSERTITLE)) {
  	result.setUSERTITLE(uSERTITLE);
  }

  var uSERTYPE = getParamValue(params.usertype, assigns.uSERTYPE);
  if (hasValue(uSERTYPE)) {
  	result.setUSERTYPE(uSERTYPE);
  }

	return result;
}

function fillARRAYOFUSERFIELD(serviceHelper, params, assigns) {
	if (params == null) {
		return null;
	}

	var result = serviceHelper.instantiate("br.com.microsiga.webservices.mtsellersalesorder.ARRAYOFUSERFIELD");

	for (var i = 0; i < params.length; i++) {
		result.getUSERFIELD().add(fillUSERFIELD(serviceHelper, params[i], assigns[i]));
	}

	return result;
}

function fillSALESORDERHEADERVIEW(serviceHelper, params, assigns) {
	if (params == null) {
		return null;
	}

	var result = serviceHelper.instantiate("br.com.microsiga.webservices.mtsellersalesorder.SALESORDERHEADERVIEW");

  var aDDITIONALEXPENSEVALUE = getParamValue(params.additionalexpensevalue, assigns.aDDITIONALEXPENSEVALUE);
  if (hasValue(aDDITIONALEXPENSEVALUE)) {
    result.setADDITIONALEXPENSEVALUE(aDDITIONALEXPENSEVALUE);
  }

  var aDJUSTMENTTYPE = getParamValue(params.adjustmenttype, assigns.aDJUSTMENTTYPE);
  if (hasValue(aDJUSTMENTTYPE))  {
    result.setADJUSTMENTTYPE(aDJUSTMENTTYPE);
  }

  var aPROBATIONTYPE = getParamValue(params.aprobationtype, assigns.aPROBATIONTYPE);
  if (hasValue(aPROBATIONTYPE))  {
    result.setAPROBATIONTYPE(aPROBATIONTYPE);
  }

  var bANKCODE = getParamValue(params.bankcode, assigns.bANKCODE);
  if (hasValue(bANKCODE))  {
    result.setBANKCODE(bANKCODE);
  }

  var bIDNUMBER = getParamValue(params.bidnumber, assigns.bIDNUMBER);
  if (hasValue(bIDNUMBER))  {
    result.setBIDNUMBER(bIDNUMBER);
  }

  var cARRIERCODE = getParamValue(params.carriercode, assigns.cARRIERCODE);
  if (hasValue(cARRIERCODE))  {
    result.setCARRIERCODE(cARRIERCODE);
  }

  var cUSTOMERCODE = getParamValue(params.customercode, assigns.cUSTOMERCODE);
  if (hasValue(cUSTOMERCODE))  {
    result.setCUSTOMERCODE(cUSTOMERCODE);
  }

  var cUSTOMERTYPE = getParamValue(params.customertype, assigns.cUSTOMERTYPE);
  if (hasValue(cUSTOMERTYPE))  {
    result.setCUSTOMERTYPE(cUSTOMERTYPE);
  }

  var cUSTOMERUNIT = getParamValue(params.customerunit, assigns.cUSTOMERUNIT);
  if (hasValue(cUSTOMERUNIT))  {
    result.setCUSTOMERUNIT(cUSTOMERUNIT);
  }

  var dELIVERYCUSTOMER = getParamValue(params.deliverycustomer, assigns.dELIVERYCUSTOMER);
  if (hasValue(dELIVERYCUSTOMER))  {
    result.setDELIVERYCUSTOMER(dELIVERYCUSTOMER);
  }

  var dELIVERYUNITCODE = getParamValue(params.deliveryunitcode, assigns.dELIVERYUNITCODE);
  if (hasValue(dELIVERYUNITCODE))  {
    result.setDELIVERYUNITCODE(dELIVERYUNITCODE);
  }

  var dISCOUNT1 = getParamValue(params.discount1, assigns.dISCOUNT1);
  if (hasValue(dISCOUNT1))  {
    result.setDISCOUNT1(dISCOUNT1);
  }

  var dISCOUNT2 = getParamValue(params.discount2, assigns.dISCOUNT2);
  if (hasValue(dISCOUNT2))  {
    result.setDISCOUNT2(dISCOUNT2);
  }

  var dISCOUNT3 = getParamValue(params.discount3, assigns.dISCOUNT3);
  if (hasValue(dISCOUNT3))  {
    result.setDISCOUNT3(dISCOUNT3);
  }

  var dISCOUNT4 = getParamValue(params.discount4, assigns.dISCOUNT4);
  if (hasValue(dISCOUNT4))  {
    result.setDISCOUNT4(dISCOUNT4);
  }

  var fINANCIALDISCOUNT = getParamValue(params.financialdiscount, assigns.fINANCIALDISCOUNT);
  if (hasValue(fINANCIALDISCOUNT))  {
    result.setFINANCIALDISCOUNT(fINANCIALDISCOUNT);
  }

  var fINANCIALINCREASE = getParamValue(params.financialincrease, assigns.fINANCIALINCREASE);
  if (hasValue(fINANCIALINCREASE))  {
    result.setFINANCIALINCREASE(fINANCIALINCREASE);
  }

  var fREIGHTTYPE = getParamValue(params.freighttype, assigns.fREIGHTTYPE);
  if (hasValue(fREIGHTTYPE))  {
    result.setFREIGHTTYPE(fREIGHTTYPE);
  }

  var fREIGHTVALUE = getParamValue(params.freightvalue, assigns.fREIGHTVALUE);
  if (hasValue(fREIGHTVALUE))  {
    result.setFREIGHTVALUE(fREIGHTVALUE);
  }

  var gROSSWEIGHT = getParamValue(params.grossweight, assigns.gROSSWEIGHT);
  if (hasValue(gROSSWEIGHT))  {
    result.setGROSSWEIGHT(gROSSWEIGHT);
  }

  var iNDEMNITYPERCENTAGE = getParamValue(params.indemnitypercentage, assigns.iNDEMNITYPERCENTAGE);
  if (hasValue(iNDEMNITYPERCENTAGE))  {
    result.setINDEMNITYPERCENTAGE(iNDEMNITYPERCENTAGE);
  }

  var iNDEMNITYVALUE = getParamValue(params.indemnityvalue, assigns.iNDEMNITYVALUE);
  if (hasValue(iNDEMNITYVALUE))  {
    result.setINDEMNITYVALUE(iNDEMNITYVALUE);
  }

  var iNDEPENDENTFREIGHT = getParamValue(params.independentfreight, assigns.iNDEPENDENTFREIGHT);
  if (hasValue(iNDEPENDENTFREIGHT))  {
    result.setINDEPENDENTFREIGHT(iNDEPENDENTFREIGHT);
  }

  var iNSURANCEVALUE = getParamValue(params.insurancevalue, assigns.iNSURANCEVALUE);
  if (hasValue(iNSURANCEVALUE))  {
    result.setINSURANCEVALUE(iNSURANCEVALUE);
  }

  var iNVOICEMESSAGE = getParamValue(params.invoicemessage, assigns.iNVOICEMESSAGE);
  if (hasValue(iNVOICEMESSAGE))  {
    result.setINVOICEMESSAGE(iNVOICEMESSAGE);
  }

  var nETWEIGHT = getParamValue(params.netweight, assigns.nETWEIGHT);
  if (hasValue(nETWEIGHT))  {
    result.setNETWEIGHT(nETWEIGHT);
  }

  var oRDERID = getParamValue(params.orderid, assigns.oRDERID);
  if (hasValue(oRDERID))  {
    result.setORDERID(oRDERID);
  }

  var oRDERTYPECODE = getParamValue(params.ordertypecode, assigns.oRDERTYPECODE);
  if (hasValue(oRDERTYPECODE))  {
    result.setORDERTYPECODE(oRDERTYPECODE);
  }

  result.setPACKAGESVOLUMES(fillARRAYOFGENERICSTRUCT(serviceHelper, params.packagesvolumes, assigns.pACKAGESVOLUMES));
  var pAYMENTPLANCODE = getParamValue(params.paymentplancode, assigns.pAYMENTPLANCODE);
  if (hasValue(pAYMENTPLANCODE))  {
    result.setPAYMENTPLANCODE(pAYMENTPLANCODE);
  }

  var pRICELISTCODE = getParamValue(params.pricelistcode, assigns.pRICELISTCODE);
  if (hasValue(pRICELISTCODE))  {
    result.setPRICELISTCODE(pRICELISTCODE);
  }

  var pRICEWITHSERVICETAX = getParamValue(params.pricewithservicetax, assigns.pRICEWITHSERVICETAX);
  if (hasValue(pRICEWITHSERVICETAX))  {
    result.setPRICEWITHSERVICETAX(pRICEWITHSERVICETAX);
  }

  var rEDELIVERYCARRIERCODE = getParamValue(params.redeliverycarriercode, assigns.rEDELIVERYCARRIERCODE);
  if (hasValue(rEDELIVERYCARRIERCODE))  {
    result.setREDELIVERYCARRIERCODE(rEDELIVERYCARRIERCODE);
  }

  var rEGISTERDATE = serviceHelper.getDate(getParamValue(params.registerdate, assigns.rEGISTERDATE));
  if (hasValue(rEGISTERDATE))  {
    result.setREGISTERDATE(rEGISTERDATE);
  }

  result.setSALESORDERCURRENCY(fillBigInteger(serviceHelper, params.salesordercurrency, assigns.sALESORDERCURRENCY));
  result.setSELLERS(fillARRAYOFGENERICSTRUCT(serviceHelper, params.sellers, assigns.sELLERS));
  var sTANDARDMESSAGE1 = getParamValue(params.standardmessage1, assigns.sTANDARDMESSAGE1);
  if (hasValue(sTANDARDMESSAGE1))  {
    result.setSTANDARDMESSAGE1(sTANDARDMESSAGE1);
  }

  result.setUSERFIELDS(fillARRAYOFUSERFIELD(serviceHelper, params.userfields, assigns.uSERFIELDS));

	return result;
}

function fillSALESORDERITEMVIEW(serviceHelper, params, assigns) {
	if (params == null) {
		return null;
	}

	var result = serviceHelper.instantiate("br.com.microsiga.webservices.mtsellersalesorder.SALESORDERITEMVIEW");

	if(params.commissionspercentage != null){
		result.setCOMMISSIONSPERCENTAGE(fillARRAYOFGENERICSTRUCT(serviceHelper, params.commissionspercentage, assigns.cOMMISSIONSPERCENTAGE));
	}
  var cUSTOMERORDERNUMBER = getParamValue(params.customerordernumber, assigns.cUSTOMERORDERNUMBER);
  if (hasValue(cUSTOMERORDERNUMBER)) {
  	result.setCUSTOMERORDERNUMBER(cUSTOMERORDERNUMBER);
  }

  var dELIVERYDATE = serviceHelper.getDate(getParamValue(params.deliverydate, assigns.dELIVERYDATE));
  if (hasValue(dELIVERYDATE)) {
  	result.setDELIVERYDATE(dELIVERYDATE);
  }

  var dISCOUNTPERCENTAGE = getParamValue(params.discountpercentage, assigns.dISCOUNTPERCENTAGE);
  if (hasValue(dISCOUNTPERCENTAGE)) {
  	result.setDISCOUNTPERCENTAGE(dISCOUNTPERCENTAGE);
  }

  var fISCALOPERATION = getParamValue(params.fiscaloperation, assigns.fISCALOPERATION);
  if (hasValue(fISCALOPERATION)) {
  	result.setFISCALOPERATION(fISCALOPERATION);
  }

  var iTEMDISCOUNTVALUE = getParamValue(params.itemdiscountvalue, assigns.iTEMDISCOUNTVALUE);
  if (hasValue(iTEMDISCOUNTVALUE)) {
  	result.setITEMDISCOUNTVALUE(iTEMDISCOUNTVALUE);
  }

  var iTEMOUTFLOWTYPE = getParamValue(params.itemoutflowtype, assigns.iTEMOUTFLOWTYPE);
  if (hasValue(iTEMOUTFLOWTYPE)) {
  	result.setITEMOUTFLOWTYPE(iTEMOUTFLOWTYPE);
  }

  var lOCATION = getParamValue(params.location, assigns.lOCATION);
  if (hasValue(lOCATION)) {
  	result.setLOCATION(lOCATION);
  }

  var lOTNUMBER = getParamValue(params.lotnumber, assigns.lOTNUMBER);
  if (hasValue(lOTNUMBER)) {
  	result.setLOTNUMBER(lOTNUMBER);
  }

  var mANUFACTURERCODE = getParamValue(params.manufacturercode, assigns.mANUFACTURERCODE);
  if (hasValue(mANUFACTURERCODE)) {
  	result.setMANUFACTURERCODE(mANUFACTURERCODE);
  }

  var mANUFACTURERUNIT = getParamValue(params.manufacturerunit, assigns.mANUFACTURERUNIT);
  if (hasValue(mANUFACTURERUNIT)) {
  	result.setMANUFACTURERUNIT(mANUFACTURERUNIT);
  }

  var nETTOTAL = getParamValue(params.nettotal, assigns.nETTOTAL);
  if (hasValue(nETTOTAL)) {
  	result.setNETTOTAL(parseFloat(nETTOTAL));
  }

  var nETUNITPRICE = getParamValue(params.netunitprice, assigns.nETUNITPRICE);
  if (hasValue(nETUNITPRICE)) {
  	result.setNETUNITPRICE(parseFloat(nETUNITPRICE));
  }

  var oPERATIONTYPE = getParamValue(params.operationtype, assigns.oPERATIONTYPE);
  if (hasValue(oPERATIONTYPE)) {
  	result.setOPERATIONTYPE(oPERATIONTYPE);
  }

  var oRDERID = getParamValue(params.orderid, assigns.oRDERID);
  if (hasValue(oRDERID)) {
  	result.setORDERID(oRDERID);
  }

  var oRDERITEM = getParamValue(params.orderitem, assigns.oRDERITEM);
  if (hasValue(oRDERITEM)) {
  	result.setORDERITEM(oRDERITEM);
  }

  var oRIGINALINVOICE = getParamValue(params.originalinvoice, assigns.oRIGINALINVOICE);
  if (hasValue(oRIGINALINVOICE)) {
  	result.setORIGINALINVOICE(oRIGINALINVOICE);
  }

  var oRIGINALINVOICEITEM = getParamValue(params.originalinvoiceitem, assigns.oRIGINALINVOICEITEM);
  if (hasValue(oRIGINALINVOICEITEM)) {
  	result.setORIGINALINVOICEITEM(oRIGINALINVOICEITEM);
  }

  var oRIGINALINVOICESERIALID = getParamValue(params.originalinvoiceserialid, assigns.oRIGINALINVOICESERIALID);
  if (hasValue(oRIGINALINVOICESERIALID)) {
  	result.setORIGINALINVOICESERIALID(oRIGINALINVOICESERIALID);
  }

  var pOGRADEITEM = getParamValue(params.pogradeitem, assigns.pOGRADEITEM);
  if (hasValue(pOGRADEITEM)) {
  	result.setPOGRADEITEM(pOGRADEITEM);
  }

  var pOID = getParamValue(params.poid, assigns.pOID);
  if (hasValue(pOID)) {
  	result.setPOID(pOID);
  }

  var pOITEM = getParamValue(params.poitem, assigns.pOITEM);
  if (hasValue(pOITEM)) {
  	result.setPOITEM(pOITEM);
  }

  var pOSEQUENCE = getParamValue(params.posequence, assigns.pOSEQUENCE);
  if (hasValue(pOSEQUENCE)) {
  	result.setPOSEQUENCE(pOSEQUENCE);
  }

  var pRODUCTDESCRIPTION = getParamValue(params.productdescription, assigns.pRODUCTDESCRIPTION);
  if (hasValue(pRODUCTDESCRIPTION)) {
  	result.setPRODUCTDESCRIPTION(pRODUCTDESCRIPTION);
  }

  var pRODUCTID = getParamValue(params.productid, assigns.pRODUCTID);
  if (hasValue(pRODUCTID)) {
  	result.setPRODUCTID(pRODUCTID);
  }

  var pRODUCTSERIALNUMBER = getParamValue(params.productserialnumber, assigns.pRODUCTSERIALNUMBER);
  if (hasValue(pRODUCTSERIALNUMBER)) {
  	result.setPRODUCTSERIALNUMBER(pRODUCTSERIALNUMBER);
  }

  var qUANTITY = getParamValue(params.quantity, assigns.qUANTITY);
  if (hasValue(qUANTITY)) {
  	result.setQUANTITY(parseFloat(qUANTITY));
  }

  var qUANTITYAPPROVED = getParamValue(params.quantityapproved, assigns.qUANTITYAPPROVED);
  if (hasValue(qUANTITYAPPROVED)) {
  	result.setQUANTITYAPPROVED(qUANTITYAPPROVED);
  }

  var qUANTITYDELIVERED = getParamValue(params.quantitydelivered, assigns.qUANTITYDELIVERED);
  if (hasValue(qUANTITYDELIVERED)) {
  	result.setQUANTITYDELIVERED(qUANTITYDELIVERED);
  }

  var qUANTITYRELEASEDSECONDUNIT = getParamValue(params.quantityreleasedsecondunit, assigns.qUANTITYRELEASEDSECONDUNIT);
  if (hasValue(qUANTITYRELEASEDSECONDUNIT)) {
  	result.setQUANTITYRELEASEDSECONDUNIT(qUANTITYRELEASEDSECONDUNIT);
  }

  var sECONDMEASUREUNITQUANTITY = getParamValue(params.secondmeasureunitquantity, assigns.sECONDMEASUREUNITQUANTITY);
  if (hasValue(sECONDMEASUREUNITQUANTITY)) {
  	result.setSECONDMEASUREUNITQUANTITY(sECONDMEASUREUNITQUANTITY);
  }

  var sECONDUNITOFMEASURE = getParamValue(params.secondunitofmeasure, assigns.sECONDUNITOFMEASURE);
  if (hasValue(sECONDUNITOFMEASURE)) {
  	result.setSECONDUNITOFMEASURE(sECONDUNITOFMEASURE);
  }

  var sUBLOT = getParamValue(params.sublot, assigns.sUBLOT);
  if (hasValue(sUBLOT)) {
  	result.setSUBLOT(sUBLOT);
  }

  var uNITLISTPRICE = getParamValue(params.unitlistprice, assigns.uNITLISTPRICE);
  if (hasValue(uNITLISTPRICE)) {
  	result.setUNITLISTPRICE(uNITLISTPRICE);
  }

  var uNITOFMEASURE = getParamValue(params.unitofmeasure, assigns.uNITOFMEASURE);
  if (hasValue(uNITOFMEASURE)) {
  	result.setUNITOFMEASURE(uNITOFMEASURE);
  }

  result.setUSERFIELDS(fillARRAYOFUSERFIELD(serviceHelper, params.userfields, assigns.uSERFIELDS));
  var wAREHOUSE = getParamValue(params.warehouse, assigns.wAREHOUSE);
  if (hasValue(wAREHOUSE)) {
  	result.setWAREHOUSE(wAREHOUSE);
  }

	return result;
}

function fillARRAYOFSALESORDERITEMVIEW(serviceHelper, params, assigns) {
	if (params == null) {
		return null;
	}

	var result = serviceHelper.instantiate("br.com.microsiga.webservices.mtsellersalesorder.ARRAYOFSALESORDERITEMVIEW");
	for (var i = 0; i < params.length; i++) {
		result.getSALESORDERITEMVIEW().add(fillSALESORDERITEMVIEW(serviceHelper, params[i], assigns[0]));
	}
	return result;
}

function fillSALESORDERVIEW(serviceHelper, params, assigns) {
	if (params == null) {
		return null;
	}

	var result = serviceHelper.instantiate("br.com.microsiga.webservices.mtsellersalesorder.SALESORDERVIEW");

	log.info("protheus_atualiza_pedido_venda - fillSALESORDERVIEW - params");
	log.dir(params);

	result.setSOHEADER(fillSALESORDERHEADERVIEW(serviceHelper, params.sOHEADER, assigns.sOHEADER));
	result.setSOITEM(fillARRAYOFSALESORDERITEMVIEW(serviceHelper, params.sOITEM, assigns.sOITEM));

	log.info("protheus_atualiza_pedido_venda - fillSALESORDERVIEW - result");
	log.dir(result);

	return result;
}

function getObjectFactory(serviceHelper) {
	var objectFactory = serviceHelper.instantiate("br.com.microsiga.webservices.mtsellersalesorder_apw.ObjectFactory");

	return objectFactory;
}



function data() {
	return {
  "fluigService" : "PROTHEUS_MTSELLERSALESORDER",
  "operation" : "putsalesorder",
  "soapService" : "MTSELLERSALESORDER",
  "portType" : "MTSELLERSALESORDERSOAP",
  "locatorClass" : "br.com.microsiga.webservices.mtsellersalesorder_apw.MTSELLERSALESORDER",
  "portTypeMethod" : "getMTSELLERSALESORDERSOAP",
  "parameters" : [ ],
  "inputValues" : {
    "sellercode" : "000001",
    "usercode" : "MSALPHA",
    "salesorder" : {
      "sOHEADER" : {
        "aDJUSTMENTTYPE" : "",
        "aPROBATIONTYPE" : "",
        "iNDEMNITYVALUE" : "",
        "pACKAGESVOLUMES" : [ ],
        "bANKCODE" : "",
        "pAYMENTPLANCODE" : "",
        "cARRIERCODE" : "",
        "cUSTOMERUNIT" : "",
        "dELIVERYCUSTOMER" : "",
        "gROSSWEIGHT" : "",
        "fREIGHTVALUE" : "",
        "fINANCIALINCREASE" : "",
        "sTANDARDMESSAGE1" : "",
        "iNDEMNITYPERCENTAGE" : "",
        "dISCOUNT1" : "",
        "dISCOUNT2" : "",
        "nETWEIGHT" : "",
        "dISCOUNT3" : "",
        "pRICEWITHSERVICETAX" : "",
        "dISCOUNT4" : "",
        "aDDITIONALEXPENSEVALUE" : "",
        "rEGISTERDATE" : "",
        "pRICELISTCODE" : "",
        "sELLERS" : {
          "cODE" : "",
          "dESCRIPTION" : "",
          "vALUE" : ""
        },
        "uSERFIELDS" : [ ],
        "cUSTOMERCODE" : "",
        "cUSTOMERTYPE" : "",
        "dELIVERYUNITCODE" : "",
        "fREIGHTTYPE" : "",
        "oRDERID" : "",
        "iNDEPENDENTFREIGHT" : "",
        "iNVOICEMESSAGE" : "",
        "rEDELIVERYCARRIERCODE" : "",
        "bIDNUMBER" : "",
        "fINANCIALDISCOUNT" : "",
        "iNSURANCEVALUE" : "",
        "oRDERTYPECODE" : ""
      },
      "sOITEM" : [ ]
    }
  },
  "inputAssignments" : {
    "sellercode" : "VALUE",
    "usercode" : "VALUE",
    "salesorder" : {
      "sOHEADER" : {
        "aDJUSTMENTTYPE" : "VALUE",
        "aPROBATIONTYPE" : "VALUE",
        "iNDEMNITYVALUE" : "VALUE",
        "pACKAGESVOLUMES" : [ ],
        "bANKCODE" : "VALUE",
        "pAYMENTPLANCODE" : "VALUE",
        "cARRIERCODE" : "VALUE",
        "cUSTOMERUNIT" : "VALUE",
        "dELIVERYCUSTOMER" : "VALUE",
        "gROSSWEIGHT" : "VALUE",
        "fREIGHTVALUE" : "VALUE",
        "fINANCIALINCREASE" : "VALUE",
        "sTANDARDMESSAGE1" : "VALUE",
        "iNDEMNITYPERCENTAGE" : "VALUE",
        "dISCOUNT1" : "VALUE",
        "dISCOUNT2" : "VALUE",
        "nETWEIGHT" : "VALUE",
        "dISCOUNT3" : "VALUE",
        "pRICEWITHSERVICETAX" : "VALUE",
        "dISCOUNT4" : "VALUE",
        "aDDITIONALEXPENSEVALUE" : "VALUE",
        "rEGISTERDATE" : "VALUE",
        "pRICELISTCODE" : "VALUE",
        "sELLERS" : {
          "cODE" : "VALUE",
          "dESCRIPTION" : "VALUE",
          "vALUE" : "VALUE"
        },
        "uSERFIELDS" : [ ],
        "cUSTOMERCODE" : "VALUE",
        "cUSTOMERTYPE" : "VALUE",
        "dELIVERYUNITCODE" : "VALUE",
        "fREIGHTTYPE" : "VALUE",
        "oRDERID" : "VALUE",
        "iNDEPENDENTFREIGHT" : "VALUE",
        "iNVOICEMESSAGE" : "VALUE",
        "rEDELIVERYCARRIERCODE" : "VALUE",
        "bIDNUMBER" : "VALUE",
        "fINANCIALDISCOUNT" : "VALUE",
        "iNSURANCEVALUE" : "VALUE",
        "oRDERTYPECODE" : "VALUE"
      },
      "sOITEM" : [ {
    	  "cOMMISSIONSPERCENTAGE" : [],
    	  "cUSTOMERORDERNUMBER" : "VALUE",
    	  "dELIVERYDATE" : "VALUE",
    	  "dISCOUNTPERCENTAGE" : "VALUE",
    	  "fISCALOPERATION" : "VALUE",
    	  "iTEMDISCOUNTVALUE" : "VALUE",
    	  "iTEMOUTFLOWTYPE" : "VALUE",
    	  "lOCATION" : "VALUE",
    	  "lOTNUMBER" : "VALUE",
    	  "mANUFACTURERCODE" : "VALUE",
    	  "mANUFACTURERUNIT" : "VALUE",
    	  "nETTOTAL" : "VALUE",
    	  "nETUNITPRICE" : "VALUE",
    	  "oPERATIONTYPE" : "VALUE",
    	  "oRDERID" : "VALUE",
    	  "oRDERITEM" : "VALUE",
    	  "oRIGINALINVOICE" : "VALUE",
    	  "oRIGINALINVOICEITEM" : "VALUE",
    	  "oRIGINALINVOICESERIALID" : "VALUE",
    	  "pOGRADEITEM" : "VALUE",
    	  "pOID" : "VALUE",
    	  "pOITEM" : "VALUE",
    	  "pOSEQUENCE" : "VALUE",
    	  "pRODUCTDESCRIPTION" : "VALUE",
    	  "pRODUCTID" : "VALUE",
    	  "pRODUCTSERIALNUMBER" : "VALUE",
    	  "qUANTITY" : "VALUE",
    	  "qUANTITYAPPROVED" : "VALUE",
    	  "qUANTITYDELIVERED" : "VALUE",
    	  "qUANTITYRELEASEDSECONDUNIT" : "VALUE",
    	  "sECONDMEASUREUNITQUANTITY" : "VALUE",
    	  "sECONDUNITOFMEASURE" : "VALUE",
    	  "sUBLOT" : "VALUE",
    	  "uNITLISTPRICE" : "VALUE",
    	  "uNITOFMEASURE" : "VALUE",
    	  "wAREHOUSE" : "VALUE",
    	  "uSERFIELDS" : [ ]
      } ]
    }
  },
  "outputValues" : { },
  "outputAssignments" : { },
  "extraParams" : {
    "enabled" : false
  }
}
}

 function stringToBoolean(param) {
	 if(typeof(param) === 'boolean') {
		 return param;
	 }
	 if (param == null || param === 'null') {
		 return false;
	 }
	 switch(param.toLowerCase().trim()) {
		 case 'true': case 'yes': case '1': return true;
		 case 'false': case 'no': case '0': case null: return false;
		 default: return Boolean(param);
	 }
}
