function createDataset(fields, constraints, sortFields) {
	try {
		return processResult(callService(fields, constraints, sortFields), constraints);
	} catch(e) {
		return processErrorResult(e, constraints);
	}
}

function callService(fields, constraints, sortFields) {
	var serviceData = data();
	var params = serviceData.inputValues;
	var assigns = serviceData.inputAssignments;

	verifyConstraints(params, constraints);

	var serviceHelper = ServiceManager.getService(serviceData.fluigService);
	var serviceLocator = serviceHelper.instantiate(serviceData.locatorClass);
	var service = serviceLocator.getMTSELLERSALESORDERSOAP();
	var response = service.getsalesorder(getParamValue(params.usercode, assigns.usercode), getParamValue(params.sellercode, assigns.sellercode),
		getParamValue(params.orderid, assigns.orderid), getParamValue(params.queryaddwhere, assigns.queryaddwhere)
	);

	return response;
}

function defineStructure() {
	addColumn("sOHEADER");
	addColumn("sOITEM");
}

function onSync(lastSyncDate) {
	var serviceData = data();
	var synchronizedDataset = DatasetBuilder.newDataset();

	try {
		var resultDataset = processResult(callService());
		if (resultDataset != null) {
			var values = resultDataset.getValues();
			for (var i = 0; i < values.length; i++) {
				synchronizedDataset.addRow(values[i]);
			}
		}

	} catch(e) {
		log.info('Dataset synchronization error : ' + e.message);

	}
	return synchronizedDataset;
}

function verifyConstraints(params, constraints) {
	if (constraints != null) {
		for (var i = 0; i < constraints.length; i++) {
			try {
				params[constraints[i].fieldName] = JSON.parse(constraints[i].initialValue);
			} catch(e) {
				params[constraints[i].fieldName] = constraints[i].initialValue;
			}
		}
	}
}

function processResult(result, constraints) {
	var dataset = DatasetBuilder.newDataset();
	/**
	* Retorno original do dataset criado pela wizard
	* //dataset.addRow([JSONUtil.toJSON(result.getSOHEADER()), JSONUtil.toJSON(result.getSOITEM())]);
	*/

	/**
	* Retorno customizado
	*/
	var tipo = getTipo(constraints);
	if (tipo == '') {
		tipo = "SOHEADER";
	}

	if (tipo == "SOHEADER") {
		adicionaColunasSOHEADER(dataset);
		var SOHEADER = JSON.parse(JSONUtil.toJSON(result.getSOHEADER()));
		dataset.addRow(getSOHEADERasArray(SOHEADER));
	} else if (tipo == "SOITEM") {
		adicionaColunasSOITEM(dataset);
		var SOITEM = JSON.parse(JSONUtil.toJSON(result.getSOITEM()));
		for(var i=0; i< SOITEM.salesorderitemview.length; i++){
			var item = SOITEM.salesorderitemview[i];
			dataset.addRow(getSOITEMasArray(item));
		}
	} else {
		addColumn("mensagem");
		dataset.addRow(["Tipo informado é inválido, por favor informe a constraint tipo como SOITEM ou SOHEADER"]);
	}
	return dataset;
}

function getTipo(constraints) {
	var tipo = ""; //SOITEM ou SOHEADER

	if (constraints != null) {
		for (var i = 0; i < constraints.length; i++) {
			if (constraints[i].fieldName == 'tipo') {
				tipo = constraints[i].initialValue;
			}
		}
	}
	return tipo;
}

function adicionaColunasSOHEADER(dataset){

	dataset.addColumn("additionalexpensevalue");
	dataset.addColumn("adjustmenttype");
	dataset.addColumn("aprobationtype");
	dataset.addColumn("bankcode");
	dataset.addColumn("bidnumber");
	dataset.addColumn("carriercode");
	dataset.addColumn("customercode");
	dataset.addColumn("customertype");
	dataset.addColumn("customerunit");
	dataset.addColumn("deliverycustomer");
	dataset.addColumn("deliveryunitcode");
	dataset.addColumn("discount1");
	dataset.addColumn("discount2");
	dataset.addColumn("discount3");
	dataset.addColumn("discount4");
	dataset.addColumn("financialdiscount");
	dataset.addColumn("financialincrease");
	dataset.addColumn("freighttype");
	dataset.addColumn("freightvalue");
	dataset.addColumn("grossweight");
	dataset.addColumn("indemnitypercentage");
	dataset.addColumn("indemnityvalue");
	dataset.addColumn("independentfreight");
	dataset.addColumn("insurancevalue");
	dataset.addColumn("invoicemessage");
	dataset.addColumn("netweight");
	dataset.addColumn("orderid");
	dataset.addColumn("ordertypecode");
	dataset.addColumn("packagesvolumes"); //- array
	dataset.addColumn("paymentplancode");
	dataset.addColumn("pricelistcode");
	dataset.addColumn("pricewithservicetax");
	dataset.addColumn("redeliverycarriercode");
	dataset.addColumn("salesordercurrency");
	dataset.addColumn("sellers"); //- array
	dataset.addColumn("standardmessage1");
	dataset.addColumn("userfields");//- array
}

function adicionaColunasSOITEM(dataset){

	dataset.addColumn("commissionspercentage");//-array
	dataset.addColumn("customerordernumber");
	dataset.addColumn("deliverydate");
	dataset.addColumn("discountpercentage");
	dataset.addColumn("fiscaloperation");
	dataset.addColumn("itemdiscountvalue");
	dataset.addColumn("itemoutflowtype");
	dataset.addColumn("location");
	dataset.addColumn("lotnumber");
	dataset.addColumn("manufacturercode");
	dataset.addColumn("manufacturerunit");
	dataset.addColumn("nettotal");
	dataset.addColumn("netunitprice");
	dataset.addColumn("orderid");
	dataset.addColumn("orderitem");
	dataset.addColumn("originalinvoice");
	dataset.addColumn("originalinvoiceitem");
	dataset.addColumn("originalinvoiceserialid");
	dataset.addColumn("pogradeitem");
	dataset.addColumn("poid");
	dataset.addColumn("poitem");
	dataset.addColumn("posequence");
	dataset.addColumn("productdescription");
	dataset.addColumn("productid");
	dataset.addColumn("productserialnumber");
	dataset.addColumn("quantity");
	dataset.addColumn("quantityapproved");
	dataset.addColumn("quantitydelivered");
	dataset.addColumn("quantityreleasedsecondunit");
	dataset.addColumn("secondmeasureunitquantity");
	dataset.addColumn("secondunitofmeasure");
	dataset.addColumn("sublot");
	dataset.addColumn("unitlistprice");
	dataset.addColumn("unitofmeasure");
	dataset.addColumn("userfields"); //- array
	dataset.addColumn("warehouse");
}

function processErrorResult(error, constraints) {
	var dataset = DatasetBuilder.newDataset();
	var tipo = getTipo(constraints);

	var params = data().inputValues;
	verifyConstraints(params, constraints);

	dataset.addColumn('error');
	dataset.addColumn('sellercode');
	dataset.addColumn('orderid');
	dataset.addColumn('usercode');
	dataset.addColumn('tipo');

	var sellercode = isPrimitive(params.sellercode) ? params.sellercode : JSONUtil.toJSON(params.sellercode);
	var orderid = isPrimitive(params.orderid) ? params.orderid : JSONUtil.toJSON(params.orderid);
	var usercode = isPrimitive(params.usercode) ? params.usercode : JSONUtil.toJSON(params.usercode);

	dataset.addRow([error.message, sellercode, orderid, usercode, tipo]);

	return dataset;
}

function getParamValue(param, assignment) {
	if (assignment == 'VARIABLE') {
		return getValue(param);
	} else if (assignment == 'NULL') {
		return null;
	}
	return param;
}

function hasValue(value) {
	return value !== null && value !== undefined;
}

function isPrimitive(value) {
	return ((typeof value === 'string') || value.substring !== undefined) || typeof value === 'number' || typeof value === 'boolean' || typeof value === 'undefined';
}

function getObjectFactory(serviceHelper) {
	var objectFactory = serviceHelper.instantiate("br.com.microsiga.webservices.mtsellersalesorder_apw.ObjectFactory");

	return objectFactory;
}

function data() {
	return {
  "fluigService" : "PROTHEUS_MTSELLERSALESORDER",
  "operation" : "getsalesorder",
  "soapService" : "MTSELLERSALESORDER",
  "portType" : "MTSELLERSALESORDERSOAP",
  "locatorClass" : "br.com.microsiga.webservices.mtsellersalesorder_apw.MTSELLERSALESORDER",
  "portTypeMethod" : "getMTSELLERSALESORDERSOAP",
  "parameters" : [ ],
  "inputValues" : {
    "sellercode" : "000001",
    "orderid" : "000001",
    "usercode" : "MSALPHA"
  },
  "inputAssignments" : {
    "sellercode" : "VALUE",
    "orderid" : "VALUE",
    "usercode" : "VALUE",
    "queryaddwhere" : "NULL"
  },
  "outputValues" : { },
  "outputAssignments" : { },
  "extraParams" : {
    "enabled" : false
  }
}
}

function stringToBoolean(param) {
	if(typeof(param) === 'boolean') {
		return param;
	}
	if (param == null || param === 'null') {
		return false;
	}
	switch(param.toLowerCase().trim()) {
		case 'true': case 'yes': case '1': return true;
		case 'false': case 'no': case '0': case null: return false;
		default: return Boolean(param);
	}
};

function getSOHEADERasArray(SOHEADER) {
		return [
			SOHEADER.additionalexpensevalue,
			SOHEADER.adjustmenttype,
			SOHEADER.aprobationtype,
			SOHEADER.bankcode,
			SOHEADER.bidnumber,
			SOHEADER.carriercode,
			SOHEADER.customercode,
			SOHEADER.customertype,
			SOHEADER.customerunit,
			SOHEADER.deliverycustomer,
			SOHEADER.deliveryunitcode,
			SOHEADER.discount1,
			SOHEADER.discount2,
			SOHEADER.discount3,
			SOHEADER.discount4,
			SOHEADER.financialdiscount,
			SOHEADER.financialincrease,
			SOHEADER.freighttype,
			SOHEADER.freightvalue,
			SOHEADER.grossweight,
			SOHEADER.indemnitypercentage,
			SOHEADER.indemnityvalue,
			SOHEADER.independentfreight,
			SOHEADER.insurancevalue,
			SOHEADER.invoicemessage,
			SOHEADER.netweight,
			SOHEADER.orderid,
			SOHEADER.ordertypecode,
			JSONUtil.toJSON(SOHEADER.packagesvolumes), //- array
			SOHEADER.paymentplancode,
			SOHEADER.pricelistcode,
			SOHEADER.pricewithservicetax,
			SOHEADER.redeliverycarriercode,
			SOHEADER.salesordercurrency,
			JSONUtil.toJSON(SOHEADER.sellers),//- array
			SOHEADER.standardmessage1,
			JSONUtil.toJSON(SOHEADER.userfields)//- array
		];
};

function getSOITEMasArray(item) {
	return [
		JSONUtil.toJSON(item.commissionspercentage),//-array
		item.customerordernumber,
		item.deliverydate,
		item.discountpercentage,
		item.fiscaloperation,
		item.itemdiscountvalue,
		item.itemoutflowtype,
		item.location,
		item.lotnumber,
		item.manufacturercode,
		item.manufacturerunit,
		item.nettotal,
		item.netunitprice,
		item.orderid,
		item.orderitem,
		item.originalinvoice,
		item.originalinvoiceitem,
		item.originalinvoiceserialid,
		item.pogradeitem,
		item.poid,
		item.poitem,
		item.posequence,
		item.productdescription,
		item.productid,
		item.productserialnumber,
		item.quantity,
		item.quantityapproved,
		item.quantitydelivered,
		item.quantityreleasedsecondunit,
		item.secondmeasureunitquantity,
		item.secondunitofmeasure,
		item.sublot,
		item.unitlistprice,
		item.unitofmeasure,
		JSONUtil.toJSON(item.userfields), //- array
		item.warehouse,
	];
}
