/**
 * O dataset protheus_consulta_cliente partiu como base de um dataset simples de integração ao serviço de consulta de cliente do Protheus.
 * Alterado para especificar o objeto de retorno
 * Por padrão retorna dados do cliente
 * Caso especificada a constraint TIPO (ENDERECO, TELEFONE)
 * Retorna os dados da respectiva lista
 */

function createDataset(fields, constraints, sortFields) {
	try {
		return processResult(callService(fields, constraints, sortFields), constraints);
	} catch(e) {
		return processErrorResult(e, constraints);
	}
}

function callService(fields, constraints, sortFields) {
	var serviceData = data();
	var params = serviceData.inputValues;
	var assigns = serviceData.inputAssignments;

	verifyConstraints(serviceData.inputValues, constraints);

	var serviceHelper = ServiceManager.getService(serviceData.fluigService);
	var serviceLocator = serviceHelper.instantiate(serviceData.locatorClass);
	var service = serviceLocator.getMTCUSTOMERSOAP();
	var response = service.getcustomer(getParamValue(params.usercode, assigns.usercode), getParamValue(params.customerid, assigns.customerid)
		);

	return response;
}

function verifyConstraints(params, constraints) {
	if (constraints != null) {
		for (var i = 0; i < constraints.length; i++) {
			try {
				params[constraints[i].fieldName] = JSON.parse(constraints[i].initialValue);
			} catch(e) {
				params[constraints[i].fieldName] = constraints[i].initialValue;
			}
		}
	}
}

function processResult(result, constraints) {
	log.info("protheus_consulta_cliente -> result");
	log.dir(result);

	var dataset = DatasetBuilder.newDataset();

	var serviceData = data();
	var params = serviceData.inputValues;

	verifyConstraints(params, constraints);
	if(params.TIPO == "ENDERECO"){
		carregaEnderecos(dataset, result);
	}
	else{
		var campos = [];
		for (var i in result) {
			var valor = result[i];

			log.info("protheus_consulta_cliente -> i: " + i + " = " + valor);
			if(valor != null && (""+valor).indexOf("function") < 0
					&& i != "ADDRESSES" && i != "PHONES"
					&& i != "USERFIELDS" && i != "class"){
				dataset.addColumn(i);
				campos.push(i)
			}
		}
		var row = [];
		for(c in campos){
			log.info("protheus_consulta_cliente -> c: " + c + " - campos[c] " + campos[c]
			+ " = " + result[campos[c]]);
			row.push( result[campos[c]] );
		}
		dataset.addRow( row );
	}
	return dataset;
}

/**
 * Carrega linhas de endereço obtidas para o cliente consultado
 * no objeto de dataset para retorno ao consultante
 * @param dataset
 * @param result
 * @returns
 */
function carregaEnderecos(dataset, result){
	result = result.getADDRESSES().getADDRESSVIEW();

	dataset.addColumn("ADDRESS");
	dataset.addColumn("ADDRESSNUMBER");
	dataset.addColumn("COUNTRY");
	dataset.addColumn("DISTRICT");
	dataset.addColumn("DS_STATE");
	dataset.addColumn("TYPEOFADDRESS");
	dataset.addColumn("ZIPCODE");
	dataset.addColumn("DS_ZONE");

	for (var i = 0; i < result.size(); i++) {
		dataset.addRow([
			result.get(i).getADDRESS(),
      result.get(i).getADDRESSNUMBER(),
      result.get(i).getCOUNTRY(),
      result.get(i).getDISTRICT(),
      result.get(i).getSTATE(),
      result.get(i).getTYPEOFADDRESS(),
      result.get(i).getZIPCODE(),
      result.get(i).getZONE()]);
	}
}

function processErrorResult(error, constraints) {
	var dataset = DatasetBuilder.newDataset();

	var params = data().inputValues;
  verifyConstraints(params, constraints);

  dataset.addColumn('error');
	dataset.addColumn('customerid');
	dataset.addColumn('usercode');

	var customerid = isPrimitive(params.customerid) ? params.customerid : JSONUtil.toJSON(params.customerid);
	var usercode = isPrimitive(params.usercode) ? params.usercode : JSONUtil.toJSON(params.usercode);

	dataset.addRow([error.message, customerid, usercode]);

	return dataset;
}

function getParamValue(param, assignment) {
	if (assignment == 'VARIABLE') {
		return getValue(param);
	} else if (assignment == 'NULL') {
		return null;
	}
	return param;
}

function hasValue(value) {
	return value !== null && value !== undefined;
}

function isPrimitive(value) {
	return ((typeof value === 'string') || value.substring !== undefined) || typeof value === 'number' || typeof value === 'boolean' || typeof value === 'undefined';
}


function getObjectFactory(serviceHelper) {
	var objectFactory = serviceHelper.instantiate("br.com.microsiga.webservices.mtcustomer_apw.ObjectFactory");

	return objectFactory;
}



function data() {
	return {
  "fluigService" : "PROTHEUS_MTCUSTOMER",
  "operation" : "getcustomer",
  "soapService" : "MTCUSTOMER",
  "portType" : "MTCUSTOMERSOAP",
  "locatorClass" : "br.com.microsiga.webservices.mtcustomer_apw.MTCUSTOMER",
  "portTypeMethod" : "getMTCUSTOMERSOAP",
  "parameters" : [ ],
  "inputValues" : {
    "customerid" : "",
    "usercode" : "MSALPHA"
  },
  "inputAssignments" : {
    "customerid" : "VALUE",
    "usercode" : "VALUE"
  },
  "outputValues" : { },
  "outputAssignments" : { },
  "extraParams" : {
    "enabled" : false
  }
}
}

 function stringToBoolean(param) {
	 if(typeof(param) === 'boolean') {
		 return param;
	 }
	 if (param == null || param === 'null') {
		 return false;
	 }
	 switch(param.toLowerCase().trim()) {
		 case 'true': case 'yes': case '1': return true;
		 case 'false': case 'no': case '0': case null: return false;
		 default: return Boolean(param);
	 }
}
