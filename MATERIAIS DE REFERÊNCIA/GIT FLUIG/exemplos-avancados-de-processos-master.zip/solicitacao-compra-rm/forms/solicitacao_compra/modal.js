/**
 * Função para montar o modal
 * @param {*} itemData
 * @param {*} editavel
 */
function modalItens(itemData, editavel){
	let item = FLUIGC.modal({
		title: 'Itens',
		content: Mustache.render($("#tpl_modal_itens").html(), {}),
		id: 'itens-modal',
		size : "full",
		actions: [{
			'label': 'Confirmar',
			'classType' : 'btn-primary adiciona-itens'
		},{
			'label': 'Cancelar',
			'autoClose': true
		}]
	}, function(err, data) {
		if(!err) {
			hasZoom();

			if(itemData != undefined && itemData != null) {
				carregaItem(itemData);
			}

			$(".adiciona-itens").on("click", function() {
				let erro = "";
				if ($("#DESCRICAO_MODAL").val() == "" || $("#DESCRICAO_MODAL").val() == null) {
					erro += "- Informe a Descrição </br>";
				} else if($("#QUANTIDADE_MODAL").val() == "" || $("#QUANTIDADE_MODAL").val() == null || parseFloat($("#QUANTIDADE_MODAL").val()) <= 0) {
					erro += "- Informe a Quantidade </br>";
				}
				if(erro != "") {
					FLUIGC.toast({message : "Preencha os campos abaixo:<br/>" + erro, type : "danger"});
				} else {
					salvaItem(item);
				}
			});
		}

		if (modoDeVisualizacaoDoFormulario == "VIEW" || !editavel) {
			window["DESCRICAO_MODAL"].disable(true);
			$('#QUANTIDADE_MODAL').attr('readonly', true);
			$(".adiciona-itens").hide();
		} else {
			$("#QUANTIDADE_MODAL").mask('#.###.###.##0,0000', {reverse: true});
			setTimeout(function() {
				reloadZoomFilterValues("DESCRICAO_MODAL", "coligada,"+$("#codigoColigada").val());
			}, 1000);
		}
	});
}

/**
 * Função para carregar o item da tabela pai e filho oculta ao modal
 * @param {*} itemData
 */
function carregaItem(itemData) {
	$("#indice_item_modal").val(itemData.index);
	$("#IDPRD_MODAL").val(itemData.IDPRD);
	$("#CODUNDCONTROLE_MODAL").val(itemData.CODUNDCONTROLE);
	$("#QUANTIDADE_MODAL").val(itemData.QUANTIDADE);
	window["DESCRICAO_MODAL"].setValue([itemData.DESCRICAO]);
}

/**
 * Função para salvar o item do modal na tabela pai e filho oculta
 * @param {*} item
 */
function salvaItem(item) {
	let index = $("#indice_item_modal").val() == "" ? wdkAddChild("tabela_itens") : $("#indice_item_modal").val();
	$("#ID_ITEM___" + index).val($("#ID_ITEM_MODAL").val());
	$("#IDPRD___" + index).val($("#IDPRD_MODAL").val());
	$("#DESCRICAO___" + index).val(window["DESCRICAO_MODAL"].getSelectedItems());
	$("#CODUNDCONTROLE___" + index).val($("#CODUNDCONTROLE_MODAL").val());
	$("#QUANTIDADE___"+index).val($("#QUANTIDADE_MODAL").val());
	item.remove();
	recarregaItem();
}
