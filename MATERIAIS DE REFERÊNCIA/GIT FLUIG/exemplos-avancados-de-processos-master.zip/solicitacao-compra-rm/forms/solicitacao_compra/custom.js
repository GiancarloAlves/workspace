// Função para ser chamada assim que a página estiver carregada.
$(document).ready(function() {
	init();
});

function init() {
	// Caso o formulário esteja no modo de ADD, ato inicial ao abrir o formulário desabilita os campos zooms de filial e centro de custo, esses campos dependem da coligada para serem carregados
	if (modoDeVisualizacaoDoFormulario == "ADD") {
		setTimeout(function() {
			window["filial"].disable(true);
			window["centroDeCusto"].disable(true);
			window["localEstoque"].disable(true);
		}, 1000);
	}

	// Caso o campo de coligada já esteja preenchido e seja igual a atividade inicial habilita o botão de adicionar item
	if ($("#coligada").val().length > 0 && (numeroAtividadeAtual == Atividades.ZERO || numeroAtividadeAtual == Atividades.INICIO)) {
		$("#btn_table_itens").removeClass("fs-display-none");
	}

	// Adiciona evento de click para acionar o modal de itens
	$("#btn_table_itens").on("click", function() {
		modalItens(null, true);
	});

	// Carrega o datatable de itens
	recarregaItem();

	// Oculta na atividade Aprovação os botões do datatable editar e remover itens
	if (numeroAtividadeAtual == Atividades.APROVACAO) {
		$(".edita-itens, .remove-itens").hide();
	}
}

/**
 * Função padrão setSelectedZoomItem para identificar qual campo zoom acaba de
 * ser preenchido, recebe como parametro um objeto com o nome, id e outros
 * valores do campo zoom
 *
 * @param {*} selectedItem
 */
function setSelectedZoomItem(item) {
	if (item.inputId == "coligada") {
		$("#codigoColigada").val(item.CODCOLIGADA);

		// Habilita campos de filial e centro de custo depois de selecionar a coligada
		window.filial.disable(false);
		window.centroDeCusto.disable(false);

		// Passa a coligada selecionada como filtro aos campos zoom de filial e centro de custo
		reloadZoomFilterValues("filial", "coligada," + item.CODCOLIGADA);
		reloadZoomFilterValues("centroDeCusto", "coligada," + item.CODCOLIGADA);
		$("#btn_table_itens").removeClass("fs-display-none");

	} else if (item.inputId == "filial") {
		$("#codigoFilial").val(item.CODFILIAL);
		window.localEstoque.disable(false);
		reloadZoomFilterValues("localEstoque", "coligada," + $("#codigoColigada").val() + ",filial," + item.CODFILIAL);

	} else if (item.inputId == "centroDeCusto") {
		$("#codigoCentroDeCusto").val(item.CODCCUSTO);

	} else if (item.inputId == "localEstoque") {
		$("#codigoLocalEstoque").val(item.CODLOC);

	} else if (item.inputId == "DESCRICAO_MODAL") {
		$("#IDPRD_MODAL").val(item.IDPRD);
		$("#CODUNDCONTROLE_MODAL").val(item.CODUNDCONTROLE)
	}
}

/**
 * Função padrão removedZoomItem para identificar qual campo zoom acaba de ter o
 * valor removido, recebe como parametro um objeto com o nome, id e outros
 * valores do campo zoom
 *
 * @param {*} selectedItem
 */
function removedZoomItem(item) {
	if (item.inputId == "coligada") {
		$("#codigoColigada").val('');
		window["filial"].clear();
		window["centroDeCusto"].clear();
		window["localEstoque"].clear();
		window["filial"].disable(true);
		window["centroDeCusto"].disable(true);
		window["localEstoque"].disable(true);
		$("#btn_table_itens").addClass("fs-display-none");

	} else if (item.inputId == "filial") {
		$("#codigoFilial").val('');
		window["localEstoque"].disable(true);
		window["localEstoque"].clear();

	} else if (item.inputId == "centroDeCusto") {
		$("#codigoCentroDeCusto").val('');

	} else if (item.inputId == "localEstoque") {
		$("#codigoLocalEstoque").val('');

	} else if (item.inputId == "DESCRICAO_MODAL") {
		$("#IDPRD_MODAL").val('');
		$("#CODUNDCONTROLE_MODAL").val('');

	}
}
