function enableFields(form) {
  // Número da atividade atual de acordo com o diagrama
  var numeroAtividadeAtual = getValue("WKNumState");

  //Campos que sempre são bloqueados independente da atividade
  form.setEnabled("codigoSolicitante", false);
  form.setEnabled("nomeSolicitante", false);
  form.setEnabled("numeroSolicitacao", false);
  form.setEnabled("dataSolicitacao", false);
  form.setEnabled("nomeAprovador", false);
  form.setEnabled("dataAprovacao", false);
  //Painel do formulário visível apenas depois de certo momento do formulário
  form.setVisibleById("painelAprovacao", false);    

  //Condição exibir painel se está ou já passou em dada atividade
  if (numeroAtividadeAtual == Atividades.APROVACAO || form.getValue("dataAprovacao") != "") {
    form.setVisibleById("painelAprovacao", true);
    form.setEnabled("coligada", false);
    form.setEnabled("filial", false);
    form.setEnabled("centroDeCusto", false);
    form.setEnabled("localEstoque", false);

    form.setVisibleById("btn_table_itens", false);
  }
}
