function validateForm(form){
	// getValue("WKNumState"); -> Número da atividade atual de acordo com o diagrama
	var numeroAtividadeAtual = getValue("WKNumState");

	// getValue("WKNextState"); -> Número da atividade seguinte de acordo com o diagrama
	var numeroProximaAtividade = getValue("WKNextState");

	// getValue("WKCompletTask")=="true" -> Valida se a atividade foi realmente concluída ou apenas salva
	var atividadeConcluida = (getValue("WKCompletTask")=="true");

	// Se a atividade foi apenas salva ou atividade destino for igual atividade atual, não aplica validações
	if (!atividadeConcluida || numeroAtividadeAtual == numeroProximaAtividade) {
		return;
	}

	// Criado variavel para acumular as mensagens de erro e exibir de uma única vez
	var mensagemDeErro = "";

	// condição para validar o preenchimento do campo 'Descrição' nas atividades relevantes (0,4,5, e 7) utilizado .trim() para remover possíveis espaços.
	// Ex.: "   ", Resultado com .trim() : ""
	if (numeroAtividadeAtual == Atividades.INICIO || numeroAtividadeAtual == Atividades.ZERO) {
		if (valorEmBranco(form.getValue("coligada"))) {
			mensagemDeErro +=" O campo 'Coligada' não foi preenchido;\n";
		}
		if (valorEmBranco(form.getValue("filial"))) {
			mensagemDeErro +=" O campo 'Filial' não foi preenchido;\n";
		}
		if (valorEmBranco(form.getValue("centroDeCusto"))) {
			mensagemDeErro +=" O campo 'Centro de Custo' não foi preenchido;\n";
		}
		if (valorEmBranco(form.getValue("localEstoque"))) {
			mensagemDeErro +=" O campo 'Local de Estoque' não foi preenchido;\n";
		}

		/*
		* Cada linha adicionada numa tabela Pai x Filho tem um indice
		* O campos dessa linha <tr> terão adicionados aos seus atributos name três underlines. Ex.: ___1 ; ___2 etc.
		* O número após o _ é o indice. Com esse valor é possível iterar na lista de campos e obter e validar o valor dos campos em cada linha
		*/
		var indicePaiFilhoItens = form.getChildrenIndexes("tabela_itens");
		if (indicePaiFilhoItens.length == 0) {
			mensagemDeErro+= "A solicitação de compra deve ter ao menos 1 item. \n";
		}
	}

	if(mensagemDeErro != ""){
		throw mensagemDeErro;
	}
}

/**
 * Função valorEmBranco é um facilitador que evita você precisar repetir a condição completa  verificando se o valor está undefined, null ou se está vazio
 * @param value valor a ser testado
 * @returns verdadeiro caso seja null, undefined ou após a função trim() estiver vazio ou falso se tiver conteúdo
 */
function valorEmBranco(value) {
	return (value == null || value == undefined || value.trim() == "");
}
