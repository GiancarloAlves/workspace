// Função para motar o datatable
function recarregaItem() {
	datatableItem = FLUIGC.datatable('#datatable_itens', {
		dataRequest: retornaItem(),
		renderContent: "#tpl_datatable_itens",
		navButtons: {
			enabled: false
		},
		search: {
			enabled: false
		},
		actions: {
			enabled: true,
			template: '#tpl_itens_filtro',
			actionAreaStyle: 'col-md-4'
		},
		header: [
			{
				'title': 'ID Produto',
				'size': 'col-md-2'
			},{
				'title': 'Descrição',
				'size': 'col-md-5'
			},
			{
				'title': 'Unidade de Medida',
				'size': 'col-md-2'
			},
			{
				'title': 'Quantidade',
				'size': 'col-md-2'
			},
			{
				'title': '',
				'size': 'col-md-1'
			}
		]
	}, function(err, data) {
		if(!err) {
			bindDatatableItem();
			$("#filtraItensBtn").on("click", function() {
				datatableItem.reload(retornaItem(), "#tpl_datatable_itens");
				bindDatatableItem();
			});
		}
	});
}

/**
* Função utilizada para buscar os itens cadastrados na tabela pai e filho oculta
* @returns
*/
function retornaItem() {
	let valores = [];
	let campo = $("#tbody_tabela_itens").find("input");
	let filtro = $("#filtraItens").val();
	let todosOsRegistros = (filtro == undefined || filtro == null || filtro.length == 0);
	if (!todosOsRegistros) {
		filtro = filtro.toUpperCase();
	}
	let modo = (modoDeVisualizacaoDoFormulario == "MOD" || modoDeVisualizacaoDoFormulario == "ADD");

	for (let i = 0; i < campo.length; i++) {
		if(campo[i].id != null && campo[i].id != undefined && campo[i].id.indexOf("ID_ITEM___") > -1) {
			let index = campo[i].id.split("___")[1];

			// vai adicionar linha caso não tenha filtro ou se a linha possuir o conteúdo do filtro
			if(todosOsRegistros || linhaContemFiltro(index, filtro)) {
				valores.push({
					IDPRD : $("#IDPRD___" + index).val(),
					DESCRICAO : $("#DESCRICAO___" + index).val(),
					CODUNDCONTROLE : $("#CODUNDCONTROLE___" + index).val(),
					QUANTIDADE : $("#QUANTIDADE___" + index).val(),
					index : index,
					modo : modo
				});
			}
		}
	}
	return valores;
}

/**
* Função utilizada para buscar nos campos da linha atual se algum dos campos possui o texto do filtro
* @returns true se possuir e false se não possuir
*/
function linhaContemFiltro(index, filtro) {
	let fields = [$("#IDPRD___" + index), $("#DESCRICAO___" + index), $("#CODUNDCONTROLE___" + index), $("#QUANTIDADE___" + index)];
	for(let field of fields) {
		if (field.val().toUpperCase().indexOf(filtro) > -1) {
			return true;
		}
	}

	return false;
}

/**
* Função para abrir modal de visualização/edição de um item
*/
function abrirModal(item, editavel) {
	let index = this.getAttribute("index");
	modalItens({
		index : index,
		ID_ITEM : $("#ID_ITEM___" + index).val(),
		IDPRD : $("#IDPRD___" + index).val(),
		DESCRICAO : $("#DESCRICAO___" + index).val(),
		CODUNDCONTROLE : $("#CODUNDCONTROLE___" + index).val(),
		QUANTIDADE : $("#QUANTIDADE___" + index).val()
	}, editavel);
}

/**
* Função utilizada para adicionar eventos aos botões do datatable
*/
function bindDatatableItem() {
	$(".visualiza-itens").on("click", function() {
		abrirModal(false);
	});

	$(".edita-itens").on("click", function() {
		abrirModal(true);
	});

	$(".remove-itens").on("click", function() {
		let index = this.getAttribute("index");
		fnWdkRemoveChild($("#ID_ITEM___" + index).parent().parent().parent().find("i")[0]);
		datatableItem.reload(retornaItem(), "#tpl_datatable_itens");
		recarregaItem();
	});
}
