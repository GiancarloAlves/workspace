# Processo de Solicitação de Compra de RM

Este exemplo demonstra um fluxo de solicitação de compra no RM, passando por uma etapa de aprovação da solicitação por um grupo antes da efetivação de forma assíncrona da criação do registro.

Também demonstra como preencher a data atual e o código da solicitação em um campo de formulário, como fazer uma conexão para ao serviço do RM que disponibiliza acesso direto aos objetos de negócio (DataServer) e como efetivar dados no RM. E como gerenciar no formulário múltiplos campos de consulta a dataset, quando o item selecionado em um campo influencia nos filtros utilizados nos outros


## Pré-requisitos
Neste exemplo, usamos como servidor de integração um servidor **RM**. Em nossos serviços, vamos usar o ip como **rm**. Você terá que substituir pelo ip do RM.


## Configuração do ambiente

Acessar o fluig como usuário administrador, abrir o painel de controle e selecionar a opção Serviços. Na página de serviços, clicar em novo serviço.

Criar um serviço do tipo **SOAP** como nome **wsDataServer**, que é o **Serviço do RM que disponibiliza acesso direto aos objetos de negócio (DataServer)** e URL http://rm:5031/wsDataServer/MEX?wsdl

Acessar o fluig como usuário administrador, abrir o painel de controle e selecionar a opção Grupos. Inserir o grupo **compra** e incluir os usuários responsáveis por aprovar a solicitação de compra.

Pelo eclipse, exportar os datasets:
 *  **rm_consulta_centro_de_custo**
 *  **rm_consulta_coligada**
 *  **rm_consulta_estoque**
 *  **rm_consulta_filial**
 *  **rm_consulta_produto**

No eclipse, exportar o processo e o formulário de solicitação de compra.


## Resultados esperados
O usuário irá preencher o formulário informando a coligada, a filial, o centro de custo e o local de estoque. Além de ao menos um item para solicitação de compra. Todos os campos são obrigatórios.

Ao informar a coligada, os campos de filial e centro de custo são liberados e utilizam a coligada selecionada como filtro nos campos. E ao limpar o campo coligada, os campos voltam a ser bloqueados.

Ao informar a filial, o campo local de estoque é liberado e utiliza a filial selecionada como filtro. Ao limpar a filial (ou a coligada), o campo volta a ser bloqueado.

Ao movimentar para a etapa de aprovação, um dos usuários do grupo **compras** vai assumir a tarefa e pode reprovar a solicitação, encerrando-a, ou movimentar pra atividade de integração.

Essa atividade de integração é assíncrona, ou seja, o usuário do grupo compras que realiza a movimentação não precisa esperar que a ação seja concretizada. Isso inibe problemas de lentidão no serviço e permite tentativas múltiplas, mas no nosso exemplo, é realizado apenas uma tentativa. Em caso de integração realizada com sucesso, o processo é finalizado. Caso contrário, o usuário do grupo compras que fez a movimentação fica responsável por uma nova tarefa pra analisar o que deu de problema na integração e encaminhar novamente para integração ou reprovar a solicitação.


## FAQ
#### Ao tentar selecionar a coligada nenhum registro é exibido
Confira se o serviço foi cadastrado e se a URL do RM está acessível. Você pode verificar se os serviços estão acessíveis pela url http://rm:5031/wsPageIndex/
