function servicetask18(attempt, message) {
  try{
    var authService = getWebService();

    //importante passar no contexto o mesmo código de usuário usado para logar no webservice
    var context = "CodUsuario=mestre;CodColigada="+hAPI.getCardValue("codigoColigada")+";CodSistema=T";

    var xml = getServiceXML();

    // Imprime as informações que serão enviadas pelo serviço. Útil para encontrar problemas na integração mas pode gerar bastante log.
    log.info("************** XML " + xml);

    result = new String(authService.saveRecord("MovMovimentoTBCData", xml, context));

    // Valida se o resultado retornou valores corretos
    checkIsPK(result, 2);

    hAPI.setCardValue("idMov", result.split(";")[1]);
  } catch (e) {
    if (e == null) {
      e = "Erro desconhecido!";
    }
    throw "Ocorreu um erro ao salvar dados no RM: " + e;
  }
}

function getServiceXML() {
  var dataAtual = retornaDataHoraAtualSemHorario();

  var xml = "<MovMovimento>";
  xml += "<TMOV>";
  xml += "<CODCOLIGADA>" + hAPI.getCardValue("codigoColigada") + "</CODCOLIGADA>";
  xml += "<IDMOV>-1</IDMOV>";
  xml += "<CODFILIAL>" + hAPI.getCardValue("codigoFilial") + "</CODFILIAL>";
  xml += "<CODCCUSTO>" + hAPI.getCardValue("codigoCentroDeCusto") + "</CODCCUSTO>";
  xml += "<CODLOC>" + hAPI.getCardValue("codigoLocalEstoque") + "</CODLOC>";
  xml += "<CODLOCDESTINO>" + hAPI.getCardValue("codigoLocalEstoque") + "</CODLOCDESTINO>";
  xml += "<CODTMV>1.1.01</CODTMV>";
  xml += "<DATAEMISSAO>" + dataAtual + "</DATAEMISSAO>";
  xml += "<CODMOEVALORLIQUIDO>R$</CODMOEVALORLIQUIDO>";
  xml += "<DATAMOVIMENTO>" + dataAtual + "</DATAMOVIMENTO>";
  xml += "<CODUSUARIO>" + RM.usuario + "</CODUSUARIO>";
  xml += "<CODFILIALDESTINO>1</CODFILIALDESTINO>";
  xml += "<DATAENTREGA>" + dataAtual + "</DATAENTREGA>";
  xml += "<USUARIOCRIACAO>" + RM.usuario + "</USUARIOCRIACAO>";
  xml += "<DATACRIACAO>" + dataAtual + "</DATACRIACAO>";
  xml += "</TMOV>";

  var itens = hAPI.getChildrenIndexes("tabela_itens");
  for (var i = 0; i < itens.length; i++) {
    xml += "<TITMMOV>";
    xml += "<CODCOLIGADA>" + hAPI.getCardValue("codigoColigada") + "</CODCOLIGADA>";
    xml += "<IDMOV>-1</IDMOV>";
    xml += "<CODUND>" + hAPI.getCardValue("CODUNDCONTROLE___"+itens[i]) + "</CODUND>";
    xml += "<NSEQITMMOV>" + (parseInt(i+1)) + "</NSEQITMMOV>";
    xml += "<IDPRD>" + hAPI.getCardValue("IDPRD___"+itens[i]) + "</IDPRD>";
    xml += "<QUANTIDADE>" + hAPI.getCardValue("QUANTIDADE___"+itens[i]) + "</QUANTIDADE>";
    xml += "</TITMMOV>";
  }
  xml += "</MovMovimento>";
  return xml;
}
