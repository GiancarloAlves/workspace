// Inclua um serviço no Fluig com o nome WSDATASERVER apontando para http://localhost:8051/wsDataServer/MEX?singlewsdl (substituir localhost pelo IP e Porta do servidor RM)//.

//usuário e senha do aplicativo RM. O mesmo utilizado para logar no sistema e que tenha permissão de acesso ao cadastro que deseja utilizar
//o nomeDoServicoAutenticacao deve ser o mesmo usado no cadastro do serviço do rm (WSDATASERVER)
RM = {
  nomeDoServicoAutenticacao: "wsDataServer",
  usuario: "mestre",
  senha: "totvs"
};

function getBasicAuthenticatedClient() {
  // Inicia a instância do serviço "wsDataServer" do RM que deve ser previamente cadastrado nos serviços do fluig
  var servico = ServiceManager.getServiceInstance(RM.nomeDoServicoAutenticacao).getBean();

  // Instancia a classe WsDataServer levando em conta o que foi informado no campo "pacote" no momento do cadastro do serviço no fluig
  var localizador = servico.instantiate("com.totvs.WsDataServer");
  var dataService = localizador.getRMIwsDataServer();

  // O valor "com.totvs.IwsDataServer" também deve estar de acordo com o valor do campo "pacote" no momento do cadastro do serviço no fluig
  return servico.getBasicAuthenticatedClient(dataService, "com.totvs.IwsDataServer", RM.usuario, RM.senha);
}

function getInitialValue(constraints, fieldName) {
  var valor = "";

  if(constraints != null && constraints != undefined) {
    for(var i = 0; i < constraints.length; i++) {
      if(constraints[i].fieldName == fieldName) {
        valor = constraints[i].initialValue;
      }
    }
  }

  return valor;
}

function getContext(coligada) {
  //Importante passar no contexto o mesmo código de usuário usado para logar no webservice
  return "CODSISTEMA=G;CODCOLIGADA="+coligada+";CODUSUARIO=" + RM.usuario;
}

function createDataset(fields, constraints, sortFields){
  // Separa os dados de filtro do webservice do RM das "constraints"
  var coligada = getInitialValue(constraints, "coligada");
  var produto = getInitialValue(constraints, "DESCRICAO");

  var filtro = "1=1" ;
  //Verifica se foi passado algum filtro pelo campo zoom
  if(produto != "") {
    filtro = "DESCRICAO LIKE '%" + produto + "%'";
  }

	// Cria os objetos do serviços com autenticação
  var autenticacao = getBasicAuthenticatedClient();

  // Realiza a chamada do método "readView" do webservice do RM passando por parâmetro o nome do dataserver RM, o filtro da consulta e o contexto que é opcional.
  // O resultado da integração será recebido pela variável "resultado". Será desconsiderada a coligada de código 0
	var resultado = autenticacao.readView("EstPrdDataBR", filtro, getContext(coligada));

  return trataRetorno(resultado);
}

function trataRetorno(resultado) {
  var xml = new XML(resultado);

  var dataset = DatasetBuilder.newDataset();
  dataset.addColumn('IDPRD');
  dataset.addColumn('CODIGOPRD');
  dataset.addColumn('DESCRICAO');
  dataset.addColumn('CODUNDCONTROLE');

	// Realiza um laço de repetição no xml tendo como base a tag GCCusto que é retornada no conteúdo da integração. Em seguida, adiciona as linhas no dataset
	for (var indice in xml.TPRODUTO) {
		var elemento = xml.TPRODUTO[indice];
		dataset.addRow([elemento.IDPRD.toString(), elemento.CODIGOPRD.toString(), elemento.DESCRICAO.toString(), elemento.CODUNDCONTROLE.toString()]);
	}
  return dataset;
}
