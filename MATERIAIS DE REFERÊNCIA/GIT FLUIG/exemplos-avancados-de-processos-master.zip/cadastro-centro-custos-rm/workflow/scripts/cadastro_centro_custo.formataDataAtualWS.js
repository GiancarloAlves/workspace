/**
 * Função para retornar a data e hora atual formatada no padrão brasileiro com data e hora zerados
 * @returns data/hora atual
 */
function retornaDataHoraAtualSemHorario(){
	return (new java.text.SimpleDateFormat('yyyy-MM-dd')).format(new Date()) + "T00:00:00";
}
