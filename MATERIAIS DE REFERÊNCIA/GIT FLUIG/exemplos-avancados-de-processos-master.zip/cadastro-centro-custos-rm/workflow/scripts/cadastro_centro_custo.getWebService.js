/**
* A API de autenticação da Totvs baseia no "Basic access authentication" do
* HTTP. Código Java para autenticação Programa responsável por integrar com os
* Webservices do RM Exemplo dev valores para os parâmetros.
* O trecho de código abaixo é fornecido por padrão pelo framework RM e pode ser baixado em
* http://tdn.totvs.com/download/attachments/211064343/DataClientfluig.js
*
* Lista de serviços disponíveis em https://api.totvs.com.br/legado/devrm/bo_rm
*/

//usuário e senha do aplicativo RM. O mesmo utilizado para logar no sistema e que tenha permissão de acesso ao cadastro que deseja utilizar
//o nomeDoServicoAutenticacao deve ser o mesmo usado no cadastro do serviço do rm (WSDATASERVER)
RM = {
  nomeDoServicoAutenticacao: "wsDataServer",
  usuario: "mestre",
  senha: "totvs"
};
function getWebService(usuario, senha) {
  var caminhoDoServico = "com.totvs.WsDataServer";

  var dataServerService = ServiceManager.getServiceInstance(RM.nomeDoServicoAutenticacao);
  if (dataServerService == null) {
    throw "Servico nao encontrado: " + RM.nomeDoServicoAutenticacao;
  }

  var serviceLocator = dataServerService.instantiate(caminhoDoServico);
  if (serviceLocator == null) {
    throw "Instancia do servico nao encontrada: " + RM.nomeDoServicoAutenticacao + " - " + caminhoDoServico;
  }

  var service = serviceLocator.getRMIwsDataServer();
  if (service == null) {
    throw "Instancia do dataserver do invalida: " + RM.nomeDoServicoAutenticacao + " - " + caminhoDoServico;
  }

  var serviceHelper = dataServerService.getBean();
  if (serviceHelper == null) {
    throw "Instancia do service helper invalida: " + RM.nomeDoServicoAutenticacao + " - " + caminhoDoServico;
  }

  var authService = serviceHelper.getBasicAuthenticatedClient(service, "com.totvs.IwsDataServer", RM.usuario, RM.senha);
  if (serviceHelper == null) {
    throw "Instancia do auth service invalida: " + RM.nomeDoServicoAutenticacao + " - " + caminhoDoServico;
  }

  return authService;
}

/**
* Valida o retorno da integração
*/
function checkIsPK(result) {
  var lines = result.split('\r');

  if (lines.length == 1) {
    var pk = result.split(';');
    if (pk.length == 2) {
      return pk[1];
    }
  }
  throw result;
}
