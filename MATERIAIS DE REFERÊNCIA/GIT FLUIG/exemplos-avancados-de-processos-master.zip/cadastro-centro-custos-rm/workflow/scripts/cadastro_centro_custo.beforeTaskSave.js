function beforeTaskSave(colleagueId,nextSequenceId,userList){
	// getValue("WKNumState"); -> Número da atividade atual de acordo com o diagrama
	var numeroAtividadeAtual = getValue("WKNumState");

	if (nextSequenceId == Atividades.FIM_CANCELADO) {
		// Limpa valor do campo codigoCentroCusto caso tenha sido preenchido, pois, a solicitação não foi aprovada
		hAPI.setCardValue("codigoCentroCusto", "");
	}
}
