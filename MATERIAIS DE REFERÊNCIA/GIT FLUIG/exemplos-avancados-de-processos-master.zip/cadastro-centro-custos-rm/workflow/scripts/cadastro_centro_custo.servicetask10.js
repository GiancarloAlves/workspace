/**
 * Realiza integração para a criação de centro de custo no RM
 * A documentação do dataserver CtbCCustoData pode ser encontrada em
 * https://api.totvs.com.br/legado/devrm/bo_rm/CtbCCustoData.html?Objeto=CtbCCustoData
 */
function servicetask10(attempt, message) {
	try {
		// Carrega o webservice wsDataServer previamente cadastrado nos serviços do fluig
		var servico = getWebService();

		// Define o contexto da integração esperado pelo webservice RM
		var contexto = "CodSistema=G;CodColigada=" + hAPI.getCardValue("codigoColigada") + ";CodUsuario=" + RM.usuario;

		// Busca na funcao retornaXMLIntegracao() o XML em formato String para enviar para o RM
		var xmlIntegracao = retornaXMLIntegracao();
		var retorno = new String(servico.saveRecord("CtbCCustoData", xmlIntegracao, contexto));

		// Valida se o resultado retornou valores corretos
		checkIsPK(retorno);
	}
	catch (e) {
		log.error(e);
		throw "Ocorreu um erro ao criar Centro de Custo: " + e;
	}
}

/**
 * Função que retorna o XML de integração no formato String
 * com os dados preenchidos no formulário
 */
function retornaXMLIntegracao() {
	return "<CtbCCusto>" +
	"  <GCCusto>" +
	"    <CODCOLIGADA>" + hAPI.getCardValue("codigoColigada") + "</CODCOLIGADA>" +
	"    <CODCCUSTO>" + hAPI.getCardValue("codigoCentroCusto") + "</CODCCUSTO>" +
	"    <NOME>" + hAPI.getCardValue("nomeCentroCusto") + "</NOME>" +
	"    <CODREDUZIDO>" + hAPI.getCardValue("codigoCentroCusto") + "</CODREDUZIDO>" +
	"    <ATIVO>T</ATIVO>" +
	"    <PERMITELANC>T</PERMITELANC>" +
	"    <CODCLASSIFICA>01</CODCLASSIFICA>" +
	"    <ENVIASPED>T</ENVIASPED>" +
	"    <DATAINCLUSAO>" + retornaDataHoraAtualSemHorario() + "</DATAINCLUSAO>" +
	"  </GCCusto>" +
	"  <CCustoCompl>" +
	"    <CODCOLIGADA>" + hAPI.getCardValue("codigoColigada") + "</CODCOLIGADA>" +
	"    <CODCCUSTO>" + hAPI.getCardValue("codigoCentroCusto") + "</CODCCUSTO>" +
	"  </CCustoCompl>" +
	"</CtbCCusto>";
}
