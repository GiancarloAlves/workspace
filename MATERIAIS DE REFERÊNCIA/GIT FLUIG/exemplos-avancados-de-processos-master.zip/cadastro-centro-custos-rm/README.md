# Processo de Cadastro de Centros de Custos de RM

Este exemplo demonstra um fluxo de cadastro de centro de custos no RM, passando por uma etapa de aprovação da solicitação por um grupo antes da efetivação da criação do registro.

Também demonstra como preencher a data atual e o código da solicitação em um campo de formulário, como fazer uma conexão para ao serviço do RM que disponibiliza acesso direto aos objetos de negócio (DataServer) e como efetivar dados no RM.


## Pré-requisitos
Neste exemplo, usamos como servidor de integração um servidor **RM**. Em nossos serviços, vamos usar o ip como **rm**. Você terá que substituir pelo ip do RM.


## Configuração do ambiente

Acessar o fluig como usuário administrador, abrir o painel de controle e selecionar a opção Serviços. Na página de serviços, clicar em novo serviço.

Criar um serviço do tipo **SOAP** como nome **wsDataServer**, que é o **Serviço do RM que disponibiliza acesso direto aos objetos de negócio (DataServer)** e URL http://rm:5031/wsDataServer/MEX?wsdl

Acessar o fluig como usuário administrador, abrir o painel de controle e selecionar a opção Grupos. Inserir o grupo **contabilidade** e incluir os usuários responsáveis por aprovar o cadastro do centro de custo.

Pelo eclipse, exportar o dataset **rm_consulta_coligada**.

No eclipse, exportar o processo e o formulário de cadastro de centro de custo.


## Resultados esperados
O usuário irá preencher o formulário informando a coligada, o nome do centro de custo a ser criado e o motivo que justifica essa criação. Todos os campos são obrigatórios.

Ao iniciar a solicitação, será criado uma atividade para que algum dos usuários do grupo contabilidade assuma.

Ao aprovar o cadastro, o responsável deve informar o código do centro de custo no formato 00.0.0.0

Ao recusar o cadastro, a solicitação é encerrada com status de cancelamento e caso tenha informado o código do centro de custo será limpo para evitar problemas.


## FAQ
#### Ao tentar selecionar a coligada nenhum registro é exibido
Confira se o serviço foi cadastrado e se a URL do RM está acessível. Você pode verificar se os serviços estão acessíveis pela url http://rm:5031/wsPageIndex/

#### Ao tentar aprovar o cadastro, retornou a mensagem de erro: "Ocorreu um erro ao criar Centro de Custo: Código inválido. Grau superior 12.3.4 não cadastrado."
Confira no RM a estrutura do código e preencha corretamente.
