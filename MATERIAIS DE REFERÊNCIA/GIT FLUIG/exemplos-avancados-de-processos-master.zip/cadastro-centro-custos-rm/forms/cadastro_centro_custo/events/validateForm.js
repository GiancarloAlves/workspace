function validateForm(form) {
	// getValue("WKNumState"); -> Número da atividade atual de acordo com o diagrama
  var numeroAtividadeAtual = getValue("WKNumState");

  // getValue("WKNextState"); -> Número da atividade seguinte de acordo com o diagrama
  var numeroProximaAtividade = getValue("WKNextState");

  // getValue("WKCompletTask")=="true" -> Valida se a atividade foi realmente concluída ou apenas salva
	var atividadeConcluida = (getValue("WKCompletTask")=="true");

  // Se a atividade foi apenas salva ou atividade destino for igual atividade atual, não aplica validações
  if (!atividadeConcluida || numeroAtividadeAtual == numeroProximaAtividade) {
    return;
  }

  // Criado variavel para acumular as mensagens de erro e exibir de uma única vez
  var mensagemDeErro = "";

	// condição para validar o preenchimento do campo 'Descrição' nas atividades relevantes (0,4,5, e 7) utilizado .trim() para remover possíveis espaços.
	// Ex.: "   ", Resultado com .trim() : ""
	if (numeroAtividadeAtual == Atividades.ZERO || numeroAtividadeAtual == Atividades.INICIO) { //Antes do processo ser iniciado ou salvo o número da primera ativade é ZERO (0)
		if (valorEmBranco(form.getValue("coligada"))) {
			mensagemDeErro += " O campo 'Coligada' não foi preenchido;\n";
		}
		if (valorEmBranco(form.getValue("nomeCentroCusto"))) {
			mensagemDeErro += " O campo 'Nome do centro de custo a ser criado' não foi preenchido;\n";
		}
		if (valorEmBranco(form.getValue("motivoCentroCusto"))) {
			mensagemDeErro += " O campo 'Motivo da criação do centro de custo' não foi preenchido; \n";
		}
	} else if (numeroAtividadeAtual == Atividades.CADASTRAR_CENTRO_CUSTO && numeroProximaAtividade == Atividades.FIM) { //Valida somente se a próxima atividade for FIM (14)
		if (valorEmBranco(form.getValue("codigoCentroCusto"))) {
			mensagemDeErro += "O campo 'Código do novo centro de custo' não foi preenchido \n";
		}
	} else if (numeroAtividadeAtual == Atividades.CADASTRAR_CENTRO_CUSTO && numeroProximaAtividade == Atividades.FIM_CANCELADO) { //Valida somente se a próxima atividade for FIM CANCELADO (13)
		if (valorEmBranco(form.getValue("obsDadosCentroCusto"))) {
			mensagemDeErro += "O campo 'Observação/Justificativa' deve ser preenchido quando a solicitação for cancelada \n";
		}
	}

	if (mensagemDeErro != "") {
		throw mensagemDeErro;
	}
}

/**
 * Função valorEmBranco é um facilitador que evita você precisar repetir a condição completa  verificando se o valor está undefined, null ou se está vazio
 * @param value valor a ser testado
 * @returns verdadeiro caso seja null, undefined ou após a função trim() estiver vazio ou falso se tiver conteúdo
 */
function valorEmBranco(value) {
	return (value == null || value == undefined || value.trim() == "");
}
