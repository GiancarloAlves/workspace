function displayFields(form,customHTML){
	// Mantém a visualização de campos do formulário igual, tanto para o modo modificação quanto visualização
	form.setShowDisabledFields(true);

	//Remove o botão padrão Fluig de impressão do formulário
	form.setHidePrintLink(true);

	// getValue("WKNumState"); -> Número da atividade atual de acordo com o diagrama
	var numeroAtividadeAtual = getValue("WKNumState");

	/*
	* form.getFormMode();
	* ADD - Momento inicial do formulário antes de iniciar e/ou salvar o processo
	* MOD - Momento a qual os campos estão editavéis para o usuário modificar após iniciar e/ou salvar o processo
	* VIEW - Modo de visualização do formulário
	*/
	var modoDeVisualizacaoDoFormulario = form.getFormMode();

	// getValue("WKUser"); ->  Retorno o código do usuário logado
	var codigoSolicitante = getValue("WKUser");

	if (modoDeVisualizacaoDoFormulario != "VIEW") {
		if (numeroAtividadeAtual == Atividades.ZERO || numeroAtividadeAtual == Atividades.INICIO) { //Antes do processo ser iniciado ou salvo o número da primera ativade é ZERO (0)
			form.setValue("codigoSolicitante", codigoSolicitante);
			form.setValue("nomeSolicitante", buscaNomeDeUsuarioPeloIdentificador(codigoSolicitante));
			form.setValue("dataSolicitacao", retornaDataAtual());
			
		} else if (numeroAtividadeAtual == Atividades.CADASTRAR_CENTRO_CUSTO) {
			form.setValue("codigoRespDadosCentroCusto", codigoSolicitante)
			form.setValue("respDadosCentroCusto", buscaNomeDeUsuarioPeloIdentificador(codigoSolicitante));
			form.setValue("dataDadosCentroCusto", retornaDataAtual());
		}
	}

	// Exemplo de injeção de javascript pelo evento de formulário displayFields
  customHTML.append("<script type='text/javascript'>");
	customHTML.append("var modoDeVisualizacaoDoFormulario = '" + modoDeVisualizacaoDoFormulario + "';");
	customHTML.append("var numeroAtividadeAtual = " + numeroAtividadeAtual + ";");
	customHTML.append("var codigoSolicitante = '" + codigoSolicitante + "';");
	customHTML.append("</script>");
}

/**
* Função para retornar a data atual
* @returns data atual
*/
function retornaDataAtual() {
	return (new java.text.SimpleDateFormat('dd/MM/yyyy')).format(new Date());
}

/**
*
* @param {*} codigoSolicitante
* @returns retorno o nome do usuário
*/
function buscaNomeDeUsuarioPeloIdentificador(codigoSolicitante) {
	var constraint = DatasetFactory.createConstraint("colleaguePK.colleagueId", codigoSolicitante , codigoSolicitante, ConstraintType.MUST);
	var dataset = DatasetFactory.getDataset("colleague", null, [constraint], null);
	return dataset.getValue(0, "colleagueName");
}
