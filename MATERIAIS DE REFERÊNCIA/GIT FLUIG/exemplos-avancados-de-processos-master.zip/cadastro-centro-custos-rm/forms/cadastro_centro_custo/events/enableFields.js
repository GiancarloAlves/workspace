function enableFields(form) {
  // Número da atividade atual de acordo com o diagrama
  var numeroAtividadeAtual = getValue("WKNumState");

  //Campos que sempre são bloqueados independente da atividade
  form.setEnabled("codigoSolicitante", false);
  form.setEnabled("nomeSolicitante", false);
  form.setEnabled("codigoSolicitacao", false);
  form.setEnabled("dataSolicitacao", false);

  // Condição para bloquear os campos informados na função form.setEnabled() de acordo com a atividade desejada
  if (numeroAtividadeAtual == Atividades.CADASTRAR_CENTRO_CUSTO) {
    form.setEnabled("coligada", false);
    form.setEnabled("codigoColigada", false);
    form.setEnabled("nomeCentroCusto", false);
    form.setEnabled("motivoCentroCusto", false);
    form.setEnabled("dataDadosCentroCusto", false);
    form.setEnabled("respDadosCentroCusto", false);
    form.setEnabled("codigoRespDadosCentroCusto", false);
  }
}
