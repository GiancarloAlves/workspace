// Função que será chamada no momento do total carregamento do formulário
$(document).ready(function() {
  // Verifica se é a atividade 5 (Cadastrar centro de custo), 14 (FIM) ou 13 (FIM_CANCELADO)

  if (numeroAtividadeAtual == Atividades.CADASTRAR_CENTRO_CUSTO || numeroAtividadeAtual == Atividades.FIM || numeroAtividadeAtual == Atividades.FIM_CANCELADO) {
    //Remove a classe "fs-display-none" do painel para torná-lo visível
    $("#painelDadosCentroCusto").removeClass("fs-display-none");
  }
});

/**
* Função padrão setSelectedZoomItem para identificar qual campo zoom acaba de ser preenchido,
* recebe como parametro um objeto com o nome, id e outros valores do campo zoom
* @param {*} selectedItem
*/
function setSelectedZoomItem(item) {
  if (item.inputId == "coligada") {
    $("#codigoColigada").val(item.CODCOLIGADA);
  }
}

/**
* Função padrão removedZoomItem para identificar qual campo zoom acaba de ter o valor removido,
* recebe como parametro um objeto com o nome, id e outros valores do campo zoom
* @param {*} selectedItem
*/
function removedZoomItem(item) {
  if (item.inputId == "coligada") {
    $("#codigoColigada").val('');
  }
}
