$(document).ready(function() {
	inverterTabelaHistorico();
});

/**
* Função para inveter os registros da tabela de historico de movimentação dos chamados,
* visto que o pai x filho padrão Fluig inclui os registros de forma ascendente.
*/
function inverterTabelaHistorico(){
	var tbody = $('#historicoChamado > tbody');
	tbody.children().each(function(i,tr){
		tbody.prepend(tr);
	});
}

/**
* Função para abrir automaticamente janela de anexo padrão Fluig
*/
function showCamera() {
	JSInterface.showCamera();
}

/**
* Função padrão setSelectedZoomItem para identificar qual campo zoom acaba de ser preenchido,
* recebe como parametro um objeto com o nome, id e outros valores do campo zoom
* @param {*} selectedItem
*/
function setSelectedZoomItem(selectedItem) {
	if(selectedItem.inputId == "nomeGrupoAtendimento"){
		$("#codigoGrupoAtendimento").val(selectedItem.groupId);
	}
}

/**
* Função padrão removedZoomItem para identificar qual campo zoom acaba de ter o valor removido,
* recebe como parametro um objeto com o nome, id e outros valores do campo zoom
* @param {*} selectedItem
*/
function removedZoomItem(selectedItem) {
	if(selectedItem.inputId == "nomeGrupoAtendimento"){
		$("#codigoGrupoAtendimento").val('');
	}

}
