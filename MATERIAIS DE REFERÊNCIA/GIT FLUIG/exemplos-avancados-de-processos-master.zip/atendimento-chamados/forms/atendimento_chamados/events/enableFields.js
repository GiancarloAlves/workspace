function enableFields(form) {
  // Campos que sempre são bloqueados independente da atividade
  form.setEnabled("codigoSolicitacao", false);
  form.setEnabled("codigoSolicitante", false);
  form.setEnabled("nomeSolicitante", false);
  form.setEnabled("dataSolicitacao", false);
  form.setEnabled("usuarioChamado", false);

  // Campos da tabela paixfilho de histórico que sempre são bloqueados independente da atividade
  var indexes = form.getChildrenIndexes("historicoChamado");
  for (var i = 0; i < indexes.length; i++) {
    form.setEnabled("usuarioHistorico___" + indexes[i], false);
    form.setEnabled("dataHistorico___" + indexes[i], false);
    form.setEnabled("descricaoHistorico___" + indexes[i], false);
  }

  // Número da atividade atual de acordo com o diagrama
  var numeroAtividadeAtual = getValue("WKNumState");

  // Desabilita o campo nomeGrupoAtendimento para todas as atividades, com exceção da primeira (0 e 4)
  if(numeroAtividadeAtual != Atividades.ZERO && numeroAtividadeAtual != Atividades.INICIO){
    form.setEnabled("nomeGrupoAtendimento", false);
  }
}
