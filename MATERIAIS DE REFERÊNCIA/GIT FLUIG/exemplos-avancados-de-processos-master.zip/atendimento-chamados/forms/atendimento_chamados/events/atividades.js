var Atividades = {
	ZERO: 0,
	INICIO: 4,	
	ATENDER_CHAMADO: 5,
	APROVAR_CHAMADO: 7,
	FIM: 9
};