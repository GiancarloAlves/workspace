// Função para ser chamada assim que a página estiver carregada.
$(document).ready(function() {
  init();
});

function init(){
  // A classe fs-display-none disponível no style-guide ocultar qualquer elemento que ela seja inserida.
  // Neste case utilizamos a classe para ocultar o painel de pesquisa de satisfação na atividade inicial e exibir na atividade de pesquisa de satisfação
  if (numeroAtividadeAtual == Atividades.INICIO || numeroAtividadeAtual == Atividades.ZERO) {
    $("#divPesquisaSatisfacao").addClass("fs-display-none");
  } else if (numeroAtividadeAtual == Atividades.RESPONDER_PESQUISA_SATISFACAO) {
    $("#divPesquisaSatisfacao").removeClass("fs-display-none");
  }
}
