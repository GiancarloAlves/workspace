function enableFields(form) {
  //Campos que sempre são bloqueados independente da atividade
  form.setEnabled("codigoSolicitante", false);
  form.setEnabled("nomeSolicitante", false);
  form.setEnabled("codigoSolicitacao", false);
  form.setEnabled("dataSolicitacao", false);
  form.setEnabled("codigoSolicitacaoOrigem", false);
  form.setEnabled("nomeSolicitanteChamado", false);
  form.setEnabled("nomeAtendente", false);
}
