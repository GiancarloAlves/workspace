# Processo de atendimento de chamados

Este exemplo demonstra um fluxo de atendimento de chamados, copiando os anexos da solicitação para uma pasta específica do fluig e ao final do atendimento criando uma sub-processo de pesquisa de satisfação que não trava a solicitação principal.

Também demonstra como preencher a data atual e o código da solicitação em um campo de formulário, como utilizar um template customizado de e-mail para acompanhamento da solicitação e como usar o mecanismo de atribuição customizado.

## Configuração do ambiente

Acessar o fluig como usuário administrador, abrir o painel de controle e selecionar a opção Template de e-mails. Na página de templates, clicar em adicionar. Usar o código **tpl_atendimento_chamados** (ou se usar outro nome, editar o script workflow/scripts/atendimento_chamados.constantes.js) e inserir arquivo templates/tpl_atendimento_chamados.html. Crie o template para todos os idiomas para evitar problemas de configurações de idioma do usuário.

Pelo eclipse, exportar o mecanismo customizado **poolFromForm** com este mesmo nome (ou editar o mecanismo de atribuição da atividade Atender selecionando o mecanismo criado)

No fluig, abrir a página de documentos e criar uma pasta onde serão movidos os anexos.

Nas propriedades do diagrama, acessar a aba extensão, e configurar a constante pasta_chamados com o código da pasta criada acima.

Exportar o processo e o formulário de pesquisa de satisfação

Exportar o processo e o formulário de atendimento de chamados.



## Resultados esperados
O usuário irá preencher o formulário informando o grupo de atendimento e incluindo os anexos do chamados. Estes dois são os campos obrigatórios do formulário.

Ao movimentar para atividade Atender, os usuários do grupo de atendimento irão receber um e-mail no template customizado, e será criado uma atividade para que algum membro assuma.

Todas as descrições de movimentação ficam armazenadas e são exibidas no histórico do chamado dentro do formulário.

Se o solicitante reprovar o atendimento, a solicitação volta para o atendente responsável, que é notificado por e-mail.

Ao aprovar o atendimento, será iniciado uma nova solicitação para o usuário com a pesquisa de satisfação.

O usuário deve responder a pesquisa informando o nível de satisfação.

## FAQ
#### Ao tentar aprovar o atendimento, retornou a mensagem de erro: "Definição do Processo não encontrada"
Você não exportou o processo pesquisa_satisfação. Exporte o processo marcando a opção liberar versão.

#### Ao tentar aprovar o atendimento, retornou a mensagem de erro: "Versão do Processo não encontrada."
O processo pesquisa_satisfação não tem versão liberada.. Exporte o processo novamente marcando a opção liberar versão

#### Ao tentar aprovar o atendimento, retornou a mensagem de erro: "Não é possível publicar anexo workflow na pasta Meus Documentos."
Configure nas propriedades do processo outra pasta. Não é permitido uma pasta dentro dos Meus Documentos.

#### Ao tentar aprovar o atendimento, retornou a mensagem de erro: "Documento inexistente ou permissão insuficiente."
A pasta configurada nas propriedades não existe ou o usuário que solicitou o atendimento não tem permissões nela. Modifique a pasta utilizada ou as permissões dela.

