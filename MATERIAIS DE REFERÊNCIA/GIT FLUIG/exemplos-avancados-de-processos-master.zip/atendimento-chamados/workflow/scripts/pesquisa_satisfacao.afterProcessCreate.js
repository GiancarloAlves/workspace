function afterProcessCreate(processId){
	// Evento de processo afterProcessCreate é executado depois do processo ser criado (iniciado ou salvo) recebe como parametro processId que é o número da solicitação gerada
	hAPI.setCardValue("codigoSolicitacao", processId);

	/*
	 * Caso o processo seja iniciado por outro processo o mesmo não executará o script do displayFields na atividade inicial
	 * consequentemente a isso não preencherá os campos de dataSolicitacao, codigoSolicitante e nomeSolicitante
	 * fazendo-se necessário executar os scripts neste evento de processo para ser acionado assim que o processo for iniciado.
	 * O evento de formulário displayFields necessita que o formulário seja apresentado para ser executado.
	 * Para mais detalhes sobre a execução dos eventos de formulário consulte a documentação: https://tdn.totvs.com/pages/releaseview.action?pageId=270924158
	 * Para mais detalhes sobre a execução dos eventos de processo consulte a documentação: https://tdn.totvs.com/display/public/fluig/Eventos+de+Processos
	 */
	hAPI.setCardValue("dataSolicitacao", retornaDataAtual());

	// getValue("WKUser"); ->  Retorno o código do usuário logado
	var codigoSolicitante = getValue("WKUser");
	
	hAPI.setCardValue("codigoSolicitante", codigoSolicitante)
	hAPI.setCardValue("nomeSolicitante", buscaNomeDeUsuarioPeloIdentificador(codigoSolicitante));
}

/**
 * Função para retornar a data atual
 * @returns data atual
 */
 function retornaDataAtual() {
	return (new java.text.SimpleDateFormat('dd/MM/yyyy')).format(new Date());
}

/**
 *
 * @param {*} codigoSolicitante
 * @returns retorno o nome do usuário
 */
function buscaNomeDeUsuarioPeloIdentificador(codigoSolicitante) {
	var constraint = DatasetFactory.createConstraint("colleaguePK.colleagueId", codigoSolicitante , codigoSolicitante, ConstraintType.MUST);
	var dataset = DatasetFactory.getDataset("colleague", null, [constraint], null);

	return dataset.getValue(0, "colleagueName");
}
