function enviarEmail(movimento, tipo, executor, assunto, destinatarios) {
	try {
		// Cria mapa de parametros para enviar ao template de e-mail
		var parametros = new java.util.HashMap();

		// Operação padrão para recuperar o código da empresa Fluig utilizada como um dos parametros de envio
		var codigoEmpresa = ""+getValue("WKCompany");

		// método da api fluig para recuperar a url do servidor utilizada como um dos parametros de envio
		var serverUrl = fluigAPI.getPageService().getServerURL();

		// recupera do formulário código da solicitação utilizada como um dos parametros de envio
		var codigoSolicitacao = ""+getValue("WKNumProces");

		// Adiciona ao mapa de parametros todos os valores esperados pelo template de e-mail
		parametros.put("SERVER_URL", serverUrl);
		parametros.put("CODIGO_EMPRESA", codigoEmpresa);
		parametros.put("CODIGO_SOLICITACAO", codigoSolicitacao);
		parametros.put("MOVIMENTO", movimento);
		parametros.put("TIPO", tipo);
		parametros.put("EXECUTOR", executor);
		parametros.put("DATA_MOVIMENTACAO", retornaDataHoraAtual());
		parametros.put("DESCRICAO_MOVIMENTO", hAPI.getCardValue("descricaoChamado"));

		// Montagem do link para consulta/interação do usuário com a solicitação workflow.
		var link = serverUrl+"/portal/p/"+codigoEmpresa+"/pageworkflowview?app_ecm_workflowview_detailsProcessInstanceID="+codigoSolicitacao;
		parametros.put("LINK", link);

		// parametro padrao obrigatorio: assunto do e-mail
		parametros.put("subject", assunto);

		// código da matricula do remetente do e-mail neste caso código do usuário logado no Fluig
		var remetente = getValue("WKUser");

		// metodo padrao Fluig para envio de e-mail customizado
		notifier.notify(remetente, Email.Template, parametros, destinatarios, "text/html");

	} catch(e) {
		log.error(e);
		throw "Ocorreu erro no envio de e-mail para os grupos de atendimento: "+e;
	}
}
