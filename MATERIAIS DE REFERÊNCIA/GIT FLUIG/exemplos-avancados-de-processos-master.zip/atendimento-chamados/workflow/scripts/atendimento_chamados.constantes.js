var Atividades = {
	ZERO: 0,
	INICIO: 4,
	ATENDER_CHAMADO: 5,
	APROVAR_CHAMADO: 7,
	FIM: 9
};


var Email = {
	Template: "tpl_atendimento_chamados", // código do template de e-mail customizado previamente desenvolvido e cadastrado no Fluig
	Abertura: {
		Assunto: "Abertura de Chamado"
	},
	Movimentacao: {
		Assunto: "Movimentação de Chamado"
	}
}
