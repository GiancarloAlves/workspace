function beforeStateEntry(sequenceId) {
	var codigoAtividadeAtual = getValue("WKNumState");

	if (sequenceId == Atividades.ATENDER_CHAMADO || sequenceId == Atividades.APROVAR_CHAMADO || sequenceId == Atividades.FIM) {
		// Inclui na tabela de histórico os dados preenchidos pelos usuários na descrição do chamado, assim como usuário executor e data/hora;
		var childData = new java.util.HashMap();
		childData.put("usuarioHistorico", hAPI.getCardValue("usuarioChamado"));
		childData.put("dataHistorico", retornaDataHoraAtual());
		childData.put("descricaoHistorico", hAPI.getCardValue("descricaoChamado"));
		hAPI.addCardChild("historicoChamado", childData);

		// Caso a atividade atual seja de abertura do chamado, entra nesta condição para enviar e-mail customizado de abertura
		if (codigoAtividadeAtual == Atividades.ZERO || codigoAtividadeAtual == Atividades.INICIO) {
			enviarEmailDeAbertura();

		// Caso a atividade atual seja aprovação do chamado e a atividade seguinte seja atender chamado, entra nesta condição para
		// enviar e-mail customizado de movimentação
		} else if (codigoAtividadeAtual == Atividades.APROVAR_CHAMADO && sequenceId == Atividades.ATENDER_CHAMADO) {
			enviarEmailDeMovimentacao();
		}

		// Limpa os campos de usuário e descrição para toda interação do chamado, visto que as interações em si são incluidas na tabela de histórico (acima)
		hAPI.setCardValue("usuarioChamado","");
		hAPI.setCardValue("descricaoChamado","");

		// Caso a atividade seguinte seja o fim da solicitação, entra nesta condição
		if (sequenceId == Atividades.FIM) {
			// Realiza a publicação dos anexos da solicitação em uma pasta de chamados
			publicarAnexosWorkflow();

			// Inicia automaticamente a solicitação de feedback
			iniciarSolicitacaoFeedback();
		}
	}
}

function enviarEmailDeAbertura() {
		// parametros passados para o evento de envio de e-mail
		var movimento = "aberto";
		var tipo = "grupo";

		// Neste caso, é o grupo de atendimento escolhido no formulário Fluig
		var executor = hAPI.getCardValue("nomeGrupoAtendimento");

		var assunto = Email.Abertura.Assunto;

		// parametros de usuários destinatarios, uma lista de matriculas ou e-mails
		var destinatarios = new java.util.ArrayList();

		// Neste caso, os usuários destinatarios serão todos os usuários do grupo de atendimento informado no campo "Grupo de Atendimento" no formulário;
		// codigoGrupoAtendimento é nome do campo que possui o valor do código do grupo cadastrado no Fluig
		var codigoGrupoAtendimento = hAPI.getCardValue("codigoGrupoAtendimento");

		// Obtém objeto com os usuários de um determinado grupo via uso da SDK, representada pelo objeto fluigAPI (https://api.fluig.com/old/sdk/com/fluig/sdk/api/FluigAPI.html)
		var usuarios = fluigAPI.getGroupService().findUsersByGroup(codigoGrupoAtendimento,"", 100, "", "");

		// Se a consulta deu certo (não é igual a null e vazio)
		if(usuarios != "" && usuarios != null){
			// Laço para adicionar cada matricula de usuário na lista de destinatários
			for(var i=0; i< usuarios.size(); i++){
				destinatarios.add(usuarios.get(i).code);
			}
		}

		// chamada ao evento enviarEmail, que irá finalizar as parametrizações e de fato enviar o e-mails aos usuários;
		enviarEmail(movimento,tipo,executor,assunto,destinatarios);
}

function enviarEmailDeMovimentacao() {
	// parametros passados para o evento de envio de e-mail
	var movimento = "movimentado";
	var tipo = "atendente";

	// Neste caso, é atendente (usuário fluig) que assumiu a solicitação deste chamado
	var executor = hAPI.getCardValue("nomeAtendente");
	var assunto = Email.Movimentacao.Assunto;

	// parametros de usuários destinatarios, uma lista de matriculas ou e-mails
	var destinatarios = new java.util.ArrayList();

	// Neste caso, o usuário destinatario é o atendente (usuario fluig) que assumiu esta solicitação de chamado;
	var codigoAtendente = hAPI.getCardValue("codigoAtendente");

	// matricula do usuario é adicionada à lista de destinatários
	destinatarios.add(codigoAtendente);

	// chamada ao evento enviarEmail, que irá finalizar as parametrizações e de fato enviar o e-mails aos usuários;
	enviarEmail(movimento,tipo,executor,assunto,destinatarios);
}
