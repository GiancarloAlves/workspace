function publicarAnexosWorkflow() {
	try {
		//Objeto de pasta que precisa ser passado para a API de criação de pastas da fluigAPI
		var objetoPasta = new com.fluig.sdk.api.document.FolderVO();

		//pega do formulário o conteúdo do campo 'codigoSolicitacao' e define como nome da pasta a ser criada
		var codigoSolicitacao = hAPI.getCardValue("codigoSolicitacao");
		objetoPasta.setDocumentDescription(codigoSolicitacao);

		//Informa para o objeto o código da pasta destino onde a nova pasta deve ser criada
		//hAPI.getAdvancedProperty("pasta_chamados"): recupera a informação da pasta destino que foi pré-cadastrada no campo extensão do processo
		var codigoPastaPai = parseInt(hAPI.getAdvancedProperty("pasta_chamados"),10);
		
		//Valida se a pasta pai existe, senão retorna erro "Documento inexistente ou permissão insuficiente"
		fluigAPI.getFolderDocumentService().get(codigoPastaPai);
		
		objetoPasta.setParentFolderId(codigoPastaPai);

		//Chamada API Fluig para criação de nova pasta
		var novaPasta = fluigAPI.getFolderDocumentService().create(objetoPasta);

		//Código da nova pasta criada
		var codigoNovaPasta = novaPasta.getDocumentId();

		publicarDocumentosNaPasta(codigoNovaPasta);

	} catch(e) {
		log.error(e);
		throw "Não foi possível publicar os anexos da solicitação: " + e;
	}
}
