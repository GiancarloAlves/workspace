/**
 * Função para retornar a data e hora atual formatada no padrão brasileiro
 * @returns data/hora atual
 */
function retornaDataHoraAtual(){
	return (new java.text.SimpleDateFormat('dd/MM/yyyy HH:mm:ss')).format(new Date());
}