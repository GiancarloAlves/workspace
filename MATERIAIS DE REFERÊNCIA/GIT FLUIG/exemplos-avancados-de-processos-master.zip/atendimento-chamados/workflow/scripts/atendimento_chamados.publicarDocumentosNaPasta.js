function publicarDocumentosNaPasta(codigoPastaPai) {
	// Instancia de calendario para ser utilizada na publicação dos arquivos
	var dataAtual = java.util.Calendar.getInstance().getTime();

	// Método padrão Fluig para listar todos os arquivos anexados à solicitação
	var docs = hAPI.listAttachments();

	// Laço de iteração para todos os arquivos listados
	for (var i = 0; i < docs.size(); i++) {

		// Recupera o documento em si, dentro deste laço
		var doc = docs.get(i);

		// Informar dados de publicação para o documento anexo recuperado
		doc.setParentDocumentId(codigoPastaPai);
		doc.setExpires(false);
		doc.setCreateDate(dataAtual);
		doc.setInheritSecurity(true);
		doc.setTopicId(1);
		doc.setUserNotify(false);
		doc.setValidationStartDate(dataAtual);
		doc.setVersionOption("0");
		doc.setUpdateIsoProperties(true);

		// Método padrão Fluig para publicar anexos de solicitação ao GED Fluig
		hAPI.publishWorkflowAttachment(doc);
	}
}
