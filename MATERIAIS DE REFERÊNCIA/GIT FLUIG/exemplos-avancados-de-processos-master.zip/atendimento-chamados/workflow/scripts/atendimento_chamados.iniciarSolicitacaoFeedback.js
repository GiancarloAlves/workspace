function iniciarSolicitacaoFeedback(){
	try {
		// Código do processo que será aberto automaticamente ao finalizar esta solicitação;
		var codigoProcessoDestino = "pesquisa_satisfacao";

		// Atividade destino ao abrir o novo processo;
		var atividadeDestino = 0;

		// Lista (do tipo String) de usuários que receberão a tarefa destino no novo processo;
		var usuariosDestino = new java.util.ArrayList();
		usuariosDestino.add(hAPI.getCardValue("codigoSolicitante"));

		// Observação de abertura do processo;
		var observacao = "Aberto a partir da solicitacao " + hAPI.getCardValue("codigoSolicitacao");

		// Se a tarefa destino deve ser automaticamente concluida ao abrir o processo
		// (neste caso está como true, pois completará a atividade de abertura indo direto para a segunda tarefa)
		// Se for false, a solicitação é salva e permanece na atividade inicial
		var completarTarefa = true;

		// Um mapa com os valores do formulário do processo para preencher na nova solicitação;
		var camposDestino = new java.util.HashMap();
		camposDestino.put("codigoSolicitacaoOrigem", hAPI.getCardValue("codigoSolicitacao"));
		camposDestino.put("codigoSolicitanteChamado", hAPI.getCardValue("codigoSolicitante"));
		camposDestino.put("nomeSolicitanteChamado", hAPI.getCardValue("nomeSolicitante"));
		camposDestino.put("codigoAtendente", hAPI.getCardValue("codigoAtendente"));
		camposDestino.put("nomeAtendente", hAPI.getCardValue("nomeAtendente"));

		// Indica que o usuário iniciará a solicitação como gestor (true) ou que o usuário iniciará a solicitação apenas como solicitante (false).
		var modoGestor = false;

		// Inicia uma solicitação workflow de um processo já cadastrado no Fluig
		hAPI.startProcess(codigoProcessoDestino, atividadeDestino, usuariosDestino, observacao, completarTarefa, camposDestino, modoGestor);
	} catch(e) {
		log.error(e);
		throw "Ocorreu erro ao inicializar solicitação de feedback: " + e;
	}
}
