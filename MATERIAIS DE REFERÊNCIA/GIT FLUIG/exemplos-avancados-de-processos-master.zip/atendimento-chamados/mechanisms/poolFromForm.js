function resolve(process,colleague){
	// Recupera o código do grupo informado no formulário
	var codigoGrupoAtendimento = hAPI.getCardValue("codigoGrupoAtendimento");

	// Cria uma lista de retorno para incluir os usuários destino
	var userList = new java.util.ArrayList();

	// Adiciona o prefixo "Pool:Group" ao código do grupo,
	// o que faz com que alguém do grupo tenha que assumir a solicitação
	userList.add('Pool:Group:' + codigoGrupoAtendimento );

	return userList;

}
