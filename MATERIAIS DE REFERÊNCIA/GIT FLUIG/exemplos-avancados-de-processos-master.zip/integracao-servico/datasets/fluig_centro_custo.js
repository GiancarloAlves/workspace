/**
 * dataset para mockup do processo integração
 */
 function createDataset(fields, constraints, sortFields) {
	var dataset = DatasetBuilder.newDataset();

	dataset.addColumn("CENTRO_CUSTO_ID");
	dataset.addColumn("CENTRO_CUSTO_NOME");

	dataset.addRow(new Array(1, "Lorem ipsum"));
	dataset.addRow(new Array(2, "dolor sit amet"));
	dataset.addRow(new Array(3, "consectetur adipiscing elit"));
	dataset.addRow(new Array(4, "sed do eiusmod"));
	dataset.addRow(new Array(5, "dolor sit amet"));
	dataset.addRow(new Array(6, "tempor incididunt"));
	dataset.addRow(new Array(7, "ut labore et dolore"));
	dataset.addRow(new Array(8, "magna aliqua"));

  return dataset;
}
