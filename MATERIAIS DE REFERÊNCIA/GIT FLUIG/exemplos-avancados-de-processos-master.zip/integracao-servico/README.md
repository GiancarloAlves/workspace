# Integração com serviços de terceiros

Este exemplo demonstra como usar um processo conectando com um serviço remoto de terceiros, enviando dados e recebendo mensagens de erro ou um código de integração.

Também demonstra como consultar um dataset interno no fluig e como usar o campo de zoom para buscar dados de um dataset próprio.

## Pré-requisitos
Neste exemplo, usamos como servidor de integração um servidor node. Para isso, primeiro é preciso instalar o node:

```bash
apt install nodejs
```

Após a instalação do node, acessar a pasta exemplos/Integração/node/ e executar o comando :

```bash
npm install
```


## Configuração do ambiente
Acessar o diretório exemplos/integracao-servico/node/ e executar o servidor node:

```bash
node server.js
```
Será exibido a mensagem **server is up at 8081**.


Acessar o fluig como usuário administrador, acessar o painel de controle, e acessar a página de Serviço e clicar em adicionar (ou acesse https://[url]/portal/p/dataservicewizard/).

**Serviço**: REST

**Nome**: integracao-motivo

**Domínio**: http://ip:8081/ (onde o **ip** é o ip da máquina onde o servidor node está rodando e 8081 é a porta, que por padrão é 8081, mas pode ser editado no exemplos/integracao-servico/node/server.js)


## Utilização do exemplo
Exportar o **dataset dataset/fluig-centro-custo.js** com o nome **descricaoCentroDeCusto**.

Exportar o processo **workflow/diagrams/integracao** para o servidor liberando versão e exportando o formulário junto. Acessar o fluig e iniciar uma solicitação do processo **integracao**.

Preencher os dados do formulário e enviar para atividade de serviço.

## Resultados esperados
Caso não seja preenchido o campo **motivo**, o servidor node vai recusar a integração enviando a mensagem **Motivo não foi informado. Informe o motivo** e esta mensagem será exibida para o usuário que está movimentando o chamado.

Caso seja informado o campo motivo, irá retornar um código de integração e gravar no campo **identificadorIntegracao**


## FAQ
#### Não posso usar a porta 8081 para o servidor node, o que eu faço?
Você pode editar essa porta editando o arquivo server.js

```js
let port = 8081;
```

#### Não consegui rodar o comando npm install ou node server.js
Verifique a versão do seu node através do comando **node -version**, pode ser que ele seja incompatível com o nosso exemplo. Usamos o node v12.16.2.

#### Após reiniciar o servidor node, o código de integração que é retornado voltou para o 1.
Sim. Esse é o resultado esperado já que gravamos o código de integração na memória do servidor. Você pode alterar o server.js para editar o valor inicial:

```js
let sequence = 1;
```

#### Ao movimentar, ocorreu um erro "Connection refused (Connection refused)"
O serviço foi cadastrado mas não está no ar. Suba o serviço via **node server.js**

#### Ao movimentar, ocorreu um erro "Serviço não encontrado com o código informado"
O serviço não foi cadastrado ou foi cadastrado com nome diferente de "integracao-motivo". Cadastre o serviço ou altere o nome no arquivo /workflow/scripts/integracao.constantes.js

