/**
* Função padrão setSelectedZoomItem para identificar qual campo zoom acaba de ser preenchido,
* recebe como parametro um objeto com o nome, id e outros valores do campo zoom
* @param {*} selectedItem
*/
function setSelectedZoomItem(selectedItem) {
  if (selectedItem.inputId == "descricaoCentroDeCusto") {
    $("#codigoCentroDeCusto").val(selectedItem.CENTRO_CUSTO_ID);
  }
}

/**
* Função padrão removedZoomItem para identificar qual campo zoom acaba de ter o valor removido,
* recebe como parametro um objeto com o nome, id e outros valores do campo zoom
* @param {*} selectedItem
*/
function removedZoomItem(selectedItem) {
  if (selectedItem.inputId == "descricaoCentroDeCusto") {
    $("#codigoCentroDeCusto").val('');
  }

}
