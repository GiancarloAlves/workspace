function validateForm(form){
	// getValue("WKNumState"); -> Número da atividade atual de acordo com o diagrama
	var numeroAtividadeAtual = getValue("WKNumState");

	// getValue("WKNextState"); -> Número da atividade seguinte de acordo com o diagrama
	var numeroProximaAtividade = getValue("WKNextState");

	// getValue("WKCompletTask")=="true" -> Valida se a atividade foi realmente concluída ou apenas salva
	var atividadeConcluida = (getValue("WKCompletTask")=="true");

	// Se a atividade foi apenas salva ou atividade destino for igual atividade atual, não aplica validações
	if (!atividadeConcluida || numeroAtividadeAtual == numeroProximaAtividade) {
		return;
	}

	// Criado variavel para acumular as mensagens de erro e exibir de uma única vez
	var mensagemDeErro = "";

	// condição para validar o preenchimento do campo 'Descrição' nas atividades relevantes (0,4,5, e 7) utilizado .trim() para remover possíveis espaços.
	// Ex.: "   ", Resultado com .trim() : ""
	if (numeroAtividadeAtual == Atividades.ZERO || numeroAtividadeAtual == Atividades.INICIO) {
		if (valorEmBranco(form.getValue("descricaoCentroDeCusto"))) {
			mensagemDeErro +=" O campo 'Centro de custo' não foi preenchido;\n";
		}
	}

	if (mensagemDeErro != "") {
		throw mensagemDeErro;
	}
}
/**
 * Função valorEmBranco é um facilitador que evita você precisar repetir a condição completa  verificando se o valor está undefined, null ou se está vazio
 * @param value valor a ser testado
 * @returns verdadeiro caso seja null, undefined ou após a função trim() estiver vazio ou falso se tiver conteúdo
 */
function valorEmBranco(value) {
	return (value == null || value == undefined || value.trim() == "");
}
