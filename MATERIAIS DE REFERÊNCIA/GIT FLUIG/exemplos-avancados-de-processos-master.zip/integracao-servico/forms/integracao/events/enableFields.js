function enableFields(form) {
  // Número da atividade atual de acordo com o diagrama
  var numeroAtividadeAtual = getValue("WKNumState");

  //Campos que sempre são bloqueados independente da atividade
  form.setEnabled("codigoSolicitante", false);
  form.setEnabled("nomeSolicitante", false);
  form.setEnabled("identificadorIntegracao", false);
  form.setEnabled("numeroSolicitacao", false);
  form.setEnabled("dataSolicitacao", false);

  //Condição para bloquear os campos descricaoCentroDeCusto somente nas atividades Verificar erro de integração e Integração
  if (numeroAtividadeAtual == Atividades.VERIFICAR_ERRO_INTEGRACAO || numeroAtividadeAtual == Atividades.SERVICO_INTEGRACAO) {
      form.setEnabled("descricaoCentroDeCusto", false);
  }
  
}
