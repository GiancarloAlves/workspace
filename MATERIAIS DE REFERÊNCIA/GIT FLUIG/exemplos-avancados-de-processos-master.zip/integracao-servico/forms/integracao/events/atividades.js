var Atividades = {
	ZERO: 0,
	INICIO: 4,	
	SERVICO_INTEGRACAO: 8,
	FIM: 7
};