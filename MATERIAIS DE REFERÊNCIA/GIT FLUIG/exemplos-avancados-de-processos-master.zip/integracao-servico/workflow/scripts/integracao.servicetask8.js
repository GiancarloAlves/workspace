function servicetask8(attempt, message) {

	var integracao_params = {
		"identificadorUsuario" : hAPI.getCardValue("identificadorUsuario") + '',
		"motivo" : hAPI.getCardValue("hidden_motivo") + '' // é usado o hidden porque vem sem as tags htmls
	}
	// Link da documentação do fluigAPI.getAuthorizeClientService : https://tdn.totvs.com/pages/releaseview.action?pageId=239041233
	var clientService = fluigAPI.getAuthorizeClientService();
	var data = {
		companyId : getValue("WKCompany") + '',
		serviceCode : Servico.nome, // código usado no cadastro do serviço
		endpoint : Servico.endpoint,  // endpoint no serviço
		method : 'post',// http method, que pode ser 'post', 'get', 'put', 'patch' ou 'delete'
		timeoutService: '3000', // timeout do serviço em ms, neste caso, 3 segundos.
		params : integracao_params ,
		options : {
			encoding : 'UTF-8',
			mediaType: 'application/json'
		},
		headers: {
			"Content-Type": 'application/json;charset=UTF-8'
		}
	};

	// O objeto data montado para realizar a requisição precisa ser convertido para um texto para ser enviado
	var vo = clientService.invoke(JSON.stringify(data));
	if (vo.getHttpStatusResult() >= 200 && vo.getHttpStatusResult() < 300) {
		try {
			// O resultado da integração é um texto sendo necessário converte-lo em objeto para podermos manipular os dados
			var result = JSON.parse(vo.getResult());
			hAPI.setCardValue("identificadorIntegracao", result.id);

			return true;
		} catch (e) {
			console.dir(vo.getResult());
			console.log(e);
			throw "Ocorreu um erro desconhecido na integração";
		}
	} else if (vo.getResult()== null || vo.getResult().isEmpty()) {
		throw "Ocorreu um erro desconhecido";
	} else {
		var errorMessage = vo.getResult();
		
		try {
			errorMessage = JSON.parse(vo.getResult()).err;
			if (errorMessage.err) {
				errorMessage = errorMessage.err;
			}
		} catch (e) {
			// ocorreu um erro pra processar o retorno como json, ignora o erro e retorna a mensagem como veio
		}
		throw "Ocorreu um erro: " + errorMessage;
	}

}
