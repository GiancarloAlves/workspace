var Servico = {
	nome: "integracao-motivo",
	endpoint: "/REST/INTEGRACAO"	
}