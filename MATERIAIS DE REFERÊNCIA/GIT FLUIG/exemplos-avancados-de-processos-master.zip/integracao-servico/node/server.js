let port = 8081;
let sequence = 1;

let express = require("express");
var bodyParser = require('body-parser');

global.app = express();
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({extended: true}));

let fs = require("fs");
let path = require('path');

app.get("/", (req, res) => {
  res.statusCode = 200;
  res.send('ok');
  res.end();
});

app.post("/REST/INTEGRACAO", (req, res) => {
  console.log(" ======= requisicao ======");
  console.log(req.body);

  if (!req.body.motivo) {
    console.error("Motivo não foi informado");
    res.statusCode = 500;
    res.json({err: "Motivo não foi informado. Informe o motivo"});

    res.end();
  } else {
    res.statusCode = 200;
    res.json({"id" : sequence++ });
    res.end();
  }
});


app.listen(port, () => {
  console.log("server is up at " + port);
});
