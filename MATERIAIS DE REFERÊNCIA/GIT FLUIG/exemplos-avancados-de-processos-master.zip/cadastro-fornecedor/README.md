# Processo de Cadastro de Fornecedor

Este exemplo demonstra um fluxo de cadastro de fornecedor, copiando os anexos da solicitação para uma pasta específica do fluig.

Também demonstra como preencher a data atual e o código da solicitação em um campo de formulário. E como usar o site viacep.com.br para consultar e retornar o endereço a partir de um cep.

## Configuração do ambiente

No fluig, abrir a página de documentos e criar uma pasta onde serão movidos os anexos.

Nas propriedades do diagrama, acessar a aba extensão, e configurar a constante *Pasta Fornecedores* com o código da pasta criada acima.

Exportar o processo e o formulário de cadastro_fornecedor.



## Resultados esperados
O usuário irá preencher o formulário informando os dados do fornecedor, com cpf ou cnpj válido. Também deverá obrigatoriamente cadastrar um endereço. Ao digitar o cep irá buscar no site viacep.com.br os dados do cep informado e deverá preencher obrigatoriamente o número do endereço. Deverá informar também ao menos uma forma de contato e ao menos um anexo.

Ao enviar, o sistema irá criar uma pasta com juntando o cpf ou cpnj e o nome do fornecedor dentro da pasta criada e configurada no processo e copiar para dentro dessa pasta recém criada os arquivos anexados no cadastro do fornecedor.

## FAQ

#### Ao tentar aprovar o atendimento, retornou a mensagem de erro: "Não é possível publicar anexo workflow na pasta Meus Documentos."
Configure nas propriedades do processo outra pasta. Não é permitido uma pasta dentro dos Meus Documentos.

#### Ao tentar aprovar o atendimento, retornou a mensagem de erro: "Documento inexistente ou permissão insuficiente."
A pasta configurada nas propriedades não existe ou o usuário que solicitou o atendimento não tem permissões nela. Modifique a pasta utilizada ou as permissões dela.
