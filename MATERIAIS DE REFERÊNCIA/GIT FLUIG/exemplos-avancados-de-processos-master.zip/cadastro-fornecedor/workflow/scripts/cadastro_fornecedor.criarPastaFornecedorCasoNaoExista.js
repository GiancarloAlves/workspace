function criarPastaFornecedorCasoNaoExista(){
	try {
		// Objeto de pasta que precisa ser passado para a API de criação de pastas da fluigAPI
		var objetoPasta = new com.fluig.sdk.api.document.FolderVO();

		// Informa para o objeto o nome da pasta a ser criada: "CPF/CNPJ - Nome do Fornecedor"
		var nomePasta = hAPI.getCardValue("cpfCnpjFornecedor") + " - " + hAPI.getCardValue("nomeFornecedor");
		objetoPasta.setDocumentDescription(nomePasta);

		// Informa para o objeto o código da pasta destino onde a nova pasta deve ser criada
		// hAPI.getAdvancedProperty("pasta_chamados"): recupera a informação da pasta destino que foi pré-cadastrada no campo extensão do processo
		var codigoPastaPai = parseInt(hAPI.getAdvancedProperty("pasta_fornecedores"),10);
		objetoPasta.setParentFolderId(codigoPastaPai);
		
		// Chamada API Fluig para criação de nova pasta, passando como parametro o objeto de pasta criado anteriormente
		var novaPasta = fluigAPI.getFolderDocumentService().create(objetoPasta);

		// Retorna o código da nova pasta criada
		return novaPasta.getDocumentId();

	} catch(e) {
		log.error(e);
		throw "Não foi possível criar a pasta do fornecedor: "+e;
	}
}
