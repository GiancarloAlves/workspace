/**
* Função para consultar se a pasta do fornecedor já existe
*/
function consultarPastaFornecedorExiste(){
	try {
		/*
		* Crio as constraints passando os parâmetros:
		* documentDescription = Nome da pasta/documento
		* parentDocumentId = Código da pasta pai
		* documentType = 1 - Pasta; 2 - Documento; 3 - Documento Externo; 4 - Fichario; 5 - Fichas; 9 - Aplicativo; 10 - Relatorio.
		* deleted = False para desconsiderar pastas excluídas
		* , código da pasta pai e tipo de documen
		*/
		var constraints = [];

		var documentDescription = hAPI.getCardValue("cpfCnpjFornecedor") + " - " + hAPI.getCardValue("nomeFornecedor");
		var parentDocumentId = parseInt(hAPI.getAdvancedProperty("pasta_fornecedores"),10);

		constraints.push(DatasetFactory.createConstraint("documentDescription", documentDescription, documentDescription, ConstraintType.MUST));
		constraints.push(DatasetFactory.createConstraint("parentDocumentId", parentDocumentId, parentDocumentId, ConstraintType.MUST));
		constraints.push(DatasetFactory.createConstraint("documentType", 1, 1, ConstraintType.MUST));
		constraints.push(DatasetFactory.createConstraint("deleted", false, false, ConstraintType.MUST));

		// Após criar as constraints, consultamos o dataset:
		var dataset = DatasetFactory.getDataset("document", null, constraints, null);

		// Caso o rowsCount seja maior que 0, significa que localizou a pasta e retornamos o id, caso contrário, a pasta não existe e retornamos null.
		if (dataset.rowsCount > 0) {
			return dataset.getValue(0, "documentPK.documentId");
		} else {
			// Então retornamos nulo
			return null;
		}
	} catch(e) {
		log.error(e);
		throw "Não foi possível consultar a pasta do fornecedor: "+e;
	}
}
