function servicetask3(attempt, message) {
	// Atividade de serviço que será executada automaticamente para criar a pasta do fornecedor e publicar os documentos

	// Primeiramente verificamos se a pasta do fornecedor já existe:
	var codigoPastaFornecedor = consultarPastaFornecedorExiste();

	// Caso o código da pasta retorne como 0, é porque ainda não existe
	if (codigoPastaFornecedor === null){
		// Chamada da função para criar a nova pasta
		codigoPastaFornecedor = criarPastaFornecedorCasoNaoExista();
	}
	
	try {
		// Publicamos o documento na pasta recém criada ou já existente
		publicarDocumentosNaPasta(codigoPastaFornecedor);
	} catch(e) {
		log.error(e);
		throw "Não foi possível publicar o documento do fornecedor: "+e;
	}
}
