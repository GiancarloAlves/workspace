function beforeTaskSave(colleagueId,nextSequenceId,userList){
	// Lista os anexos inseridos no processo.
	var docs = hAPI.listAttachments();

	// Caso não tenha sido anexado nenhum documento, dispara uma mensagem de alerta.
	if (docs.size() === 0){
		throw " é obrigatório anexar os documentos do fornecedor.";
	}
}
