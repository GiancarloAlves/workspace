$(document).ready(function(){
	// Para Iniciar o formulário com a máscara de cnpj
	selecionarTipoFornecedor();
});

function selecionarTipoFornecedor(){
	/*
	 * Verificar o tipo de fornecedor selecionado (Pessoa física ou pessoa jurídica).
	 * Caso seja pessoa jurídica, apaga o CPF e insere máscara de CNPJ no campo.
	 * Caso seja pessoa física, apaga o CNPJ e insere máscara de CPF no campo.
	 */
	if (document.getElementById("tipoFornecedorJuridica").checked == true){
		$(".pessoa-juridica").show();
		$("#cpfCnpjFornecedor").val("");
		$("#cpfCnpjFornecedor").mask("00.000.000/0000-00");

		// Limpa a label de CPF/CNPJ e insere a descrição CNPJ
		$(".cpf-cnpj").html("");
		$(".cpf-cnpj").append("CNPJ");

		// Limpa a label de Nome/Razão Social e insere a descrição Razão Social
		$(".nome-razao-social").html("");
		$(".nome-razao-social").append("Razão Social");

	} else if (document.getElementById("tipoFornecedorFisica").checked == true) {
		$(".pessoa-juridica").hide();
		$("#inscricaoEstadual").val("");
		$("#inscricaoMunicipal").val("");
		$("#cpfCnpjFornecedor").val("");
		$("#cpfCnpjFornecedor").mask("000.000.000-00");

		// Limpa a label de CPF/CNPJ e insere a descrição CPF
		$(".cpf-cnpj").html("");
		$(".cpf-cnpj").append("CPF");

		// Limpa a label de Nome/Razão Social e insere a descrição Nome
		$(".nome-razao-social").html("");
		$(".nome-razao-social").append("Nome");
	}
}

function validarCpfCnpj(campo){
	if (campo.value != ""){
		let value = campo.value.replace(/[^\d]+/g,'');
		
		if (document.getElementById("tipoFornecedorJuridica").checked == true){
			// Caso o tipo do fornecedor seja pessoa jurídica, valida o CNPJ
			if (!validarCnpj(value)) {
				FLUIGC.toast({
					title: 'Erro: ',
					message: 'CNPJ inválido',
					type: 'danger'
				});

				campo.value = "";
			}
		}else if (document.getElementById("tipoFornecedorFisica").checked == true){
			// Caso o tipo do fornecedor seja pessoa física, valida o CPF
			if (!validarCpf(value)) {
				FLUIGC.toast({
					title: 'Erro: ',
					message: 'CPF inválido',
					type: 'danger'
				});

				campo.value = "";
			}
		}
	}
}

function validarCnpj(cnpj) {
	// Código de referência: Snippet "Validar CNPJ" da sessão WCM
	cnpj = cnpj.replace(/[^\d]+/g,'');

	if(cnpj == '') return false;

	if (cnpj.length != 14)
		return false;

	// Elimina CNPJs invalidos conhecidos, ex.: 00000000000000
	if (cnpj.split(cnpj[0]).join("").length == 0)
		return false;

	// Valida DVs
	var tamanho = cnpj.length - 2
	var numeros = cnpj.substring(0,tamanho);
	var digitos = cnpj.substring(tamanho);
	var soma = 0;
	var pos = tamanho - 7;
	for (var i = tamanho; i >= 1; i--) {
		soma += numeros.charAt(tamanho - i) * pos--;
		if (pos < 2)
			pos = 9;
	}
	var resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
	if (resultado != digitos.charAt(0))
		return false;

	tamanho = tamanho + 1;
	numeros = cnpj.substring(0,tamanho);
	soma = 0;
	pos = tamanho - 7;
	for (i = tamanho; i >= 1; i--) {
		soma += numeros.charAt(tamanho - i) * pos--;
		if (pos < 2)
			pos = 9;
	}
	resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
	if (resultado != digitos.charAt(1))
			return false;

	return true;
}

function validarCpf(cpf){
	if(cpf.length == 11 ) {
        if (cpf.split(cpf[0]).join("").length == 0) {
            return false; // todos os dígitos são iguais
        }

        let v = [0,0]
        for(var i = 0; i <= 8; i++) v[0] += (i+1) * cpf[i];
        for(var i = 1; i <= 9; i++) v[1] += i * cpf[i];

        v[0] = (v[0] % 11) % 10;
        v[1] = (v[1] % 11) % 10;

        if(v[0] == cpf[9] && v[1] == cpf[10]){
            return true;
        }
	}
	return false;
}

function consultarCep(campo){
	if (campo.value == "") {
		//Caso o campo CEP esteja vazio, limpa os demais campos do endereço do fornecedor.
		limpaCamposEndereco(campo);
		return;
	}

	// Caso o campo CEP esteja preenchido: Expressão regular para remover a máscara do campo CEP
	let cepFornecedor = campo.value.replace(/\D/g, '');

	//Faz a requisição à API de validação do CEP (https://viacep.com.br/ws/0000000/json/)
	//Importente: Essa é uma ferramenta de terceiros
	let urlApiCep = "https://viacep.com.br/ws/"+cepFornecedor+"/json/";

	$.ajax({
		url: urlApiCep,
		async: true,
		type: 'GET',
		contentType: 'application/json'
	})
	.done(function(result){
		/*
		 * Verificar o retorno da API.
		 * Caso a mensagem "erro" seja true, dispara alerta na tela de CEP inválido
		 * Caso seja false, preenche os demais campos referentes ao endereço do fornecedor com os dados retornados da API
		 */
		if (result.erro === true) {
			FLUIGC.toast({
				"title": "Erro: ",
				"message": "CEP inválido.",
				"type": "danger"
			});

			limpaCamposEndereco(campo);
		} else {
			// Insere os valores retornados da API de verificação do CEP em seus respectivos campos
			$("#logradouroEndFornecedor").val(result.logradouro);
			$("#bairroEndFornecedor").val(result.bairro);
			$("#cidadeEndFornecedor").val(result.localidade);
			$("#estadoEndFornecedor").val(result.uf);
			$("#numeroEndFornecedor").focus();
		}
	})
	.fail(function(data){
		// Caso o fluig não consiga comunicação com a API, dispara alerta na tela.
		FLUIGC.toast({
			"title": "Erro: ",
			"message": "CEP inválido.",
			"type": "danger"
		});

		limpaCamposEndereco(campo);
	});
}

function limpaCamposEndereco(campo) {
	campo.value = ""

	$("#logradouroEndFornecedor").val("");
	$("#bairroEndFornecedor").val("");
	$("#cidadeEndFornecedor").val("");
	$("#estadoEndFornecedor").val("");
	$("#estadoEndFornecedor").val("");
	$("#estadoEndFornecedor").val("");
}

function inserirMascaraContato(campo){
	// Utiliza função Split para saber o índice do campo filho
	let indice = campo.id.split("___")[1];

	// Primeiro limpamos o conteúdo do campo contatoFornecedor:
	$("#contatoFornecedor___"+indice).val("");

	if (campo.value === "Celular") {
		//Insere máscara de telefone celular ao campo contatoFornecedor do índice recuperado acima:
		$("#contatoFornecedor___"+indice).mask("(00) 90000-0000");
	} else if (campo.value === "Comercial") {
		//Insere máscara de telefone fixo ao campo contatoFornecedor do índice recuperado acima:
		$("#contatoFornecedor___"+indice).mask("(00) 0000-0000");
	} else {
		//Caso não seja de nenhum dos dois tipos acima, limpa a máscara e deixa o campo contatoFornecedor livre:
		$("#contatoFornecedor___"+indice).unmask();
	}
}
