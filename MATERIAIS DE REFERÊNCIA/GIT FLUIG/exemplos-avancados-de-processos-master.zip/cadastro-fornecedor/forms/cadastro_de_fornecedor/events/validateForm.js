function validateForm(form){
  // getValue("WKNumState"); -> Número da atividade atual de acordo com o diagrama
  var numeroAtividadeAtual = getValue("WKNumState");

  // getValue("WKNextState"); -> Número da atividade seguinte de acordo com o diagrama
  var numeroProximaAtividade = getValue("WKNextState");

  // getValue("WKCompletTask")=="true" -> Valida se a atividade foi realmente concluída ou apenas salva
  var atividadeConcluida = (getValue("WKCompletTask")=="true");

  // Se a atividade foi apenas salva ou atividade destino for igual atividade atual, não aplica validações
  if (!atividadeConcluida || numeroAtividadeAtual == numeroProximaAtividade) {
    return;
  }

  // Criado variavel para acumular as mensagens de erro e exibir de uma única vez
  var mensagemDeErro = "";

	// Validamos o CPF/CNPJ do fornecedor. Caso o fornecedor seja do tipo "pessoa jurídica", os campos inscrição estadual e inscrição municipal são obrigatórios
	if (form.getValue("tipoFornecedor") == "Juridica") {
		if (valorEmBranco(form.getValue("cpfCnpjFornecedor"))) {
			mensagemDeErro += "Informe o CNPJ do fornecedor;\n";
		}
		if (valorEmBranco(form.getValue("nomeFornecedor"))) {
			mensagemDeErro += "Informe a razão social do fornecedor;\n";
		}
		if (valorEmBranco(form.getValue("inscricaoEstadual"))) {
			mensagemDeErro += "Informe a Inscrição Estadual do fornecedor;\n";
		}
		if (valorEmBranco(form.getValue("inscricaoMunicipal"))) {
			mensagemDeErro += "Informe a Inscrição Municipal do fornecedor;\n";
		}
	} else {
		if (valorEmBranco(form.getValue("cpfCnpjFornecedor"))) {
			mensagemDeErro += "Informe o CPF do fornecedor;\n";
		}
		if (valorEmBranco(form.getValue("nomeFornecedor"))) {
			mensagemDeErro += "Informe o nome do fornecedor;\n";
		}
	}

	// Condições para validar o preenchimento dos demais campos na criação da solicitação
	if (valorEmBranco(form.getValue("cepEndFornecedor"))) {
		mensagemDeErro += "Informe o CEP do endereço do fornecedor;\n";
	}
	if (valorEmBranco(form.getValue("numeroEndFornecedor"))) {
		mensagemDeErro += "Informe o número do endereço do fornecedor;\n";
	}

	// Verifica se há alguma forma de contato adicionado para o fornecedor
	var contatosFornecedor = form.getChildrenIndexes("contatosFornecedor");

	if (contatosFornecedor.length === 0) {
		mensagemDeErro += "Informe pelo menos uma forma de contato com o fornecedor;\n";
	} else {
		// Verificar se os campos filho da tabela "Contatos do Fornecedor" foram preenchidos corretamente:
		for (var i = 0; i < contatosFornecedor.length; i++) {
			if (valorEmBranco(form.getValue("tipoContatoFornecedor___"+contatosFornecedor[i]))) {
				mensagemDeErro += "Informe o tipo do "+(i+1)+"º contato do fornecedor;\n";
			}
			if (valorEmBranco(form.getValue("contatoFornecedor___"+contatosFornecedor[i]))) {
				mensagemDeErro += "Informe o "+(i+1)+"º contato do fornecedor;\n";
			}
			if (valorEmBranco(form.getValue("descrContatoFornecedor___"+contatosFornecedor[i]))) {
				mensagemDeErro += "Informe a descrição do "+(i+1)+"º contato do fornecedor;\n";
			}
		}
	}

	// Comando throw dispara mensagem de erro na tela, com as mensagens inseridas na variável mensagemDeErro
	if (mensagemDeErro !== ""){
		throw mensagemDeErro;
	}
}

/**
 * Função valorEmBranco é um facilitador que evita você precisar repetir a condição completa  verificando se o valor está undefined, null ou se está vazio
 * @param value valor a ser testado
 * @returns verdadeiro caso seja null, undefined ou após a função trim() estiver vazio ou falso se tiver conteúdo
 */
function valorEmBranco(value) {
	return (value == null || value == undefined || value.trim() == "");
}
