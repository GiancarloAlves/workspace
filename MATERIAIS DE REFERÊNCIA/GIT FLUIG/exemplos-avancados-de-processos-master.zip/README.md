# Exemplos avançados de Processo

Este repositório contém alguns exemplos de desenvolvimento de formulários e processos avançados, contando com integração com serviços remotos, do protheus e do RM.

## Processo de atendimento de chamados (atendimento-chamados)

Este exemplo demonstra um fluxo de atendimento de chamados, copiando os anexos da solicitação para uma pasta específica do fluig e ao final do atendimento criando uma sub-processo de pesquisa de satisfação que não trava a solicitação principal.

Também demonstra como preencher a data atual e o código da solicitação em um campo de formulário, como utilizar um template customizado de e-mail para acompanhamento da solicitação e como usar o mecanismo de atribuição customizado.

## Processo de atualização de Pedido de Venda (atualizacao-pedido-venda-protheus)

Este exemplo demonstra um fluxo de atualização de pedido de venda no Protheus, onde o usuário informa o pedido do protheus, é carregado os dados do pedido e os produtos. Após a alteração de quantidade e preços, o pedido passa por uma etapa de aprovação e é realizado a integração.

Também demonstra como preencher a data atual e o código da solicitação em um campo de formulário, como utilizar um template customizado de email para acompanhamento da solicitação e como usar o mecanismo de atribuição customizado.

## Processo de Cadastro de Centros de Custos de RM (cadastro-centro-custos-rm)

Este exemplo demonstra um fluxo de cadastro de centro de custos no RM, passando por uma etapa de aprovação da solicitação por um grupo antes da efetivação da criação do registro.

Também demonstra como preencher a data atual e o código da solicitação em um campo de formulário, como fazer uma conexão para ao serviço do RM que disponibiliza acesso direto aos objetos de negócio (DataServer) e como efetivar dados no RM.

## Processo de Cadastro de Fornecedor (cadastro-fornecedor)

Este exemplo demonstra um fluxo de cadastro de fornecedor, copiando os anexos da solicitação para uma pasta específica do fluig.

Também demonstra como preencher a data atual e o código da solicitação em um campo de formulário. E como usar o site viacep.com.br para consultar e retornar o endereço a partir de um cep.

## Processo de Integração com serviços de terceiros (integracao-servico)

Este exemplo demonstra como usar um processo conectando com um serviço remoto de terceiros, enviando dados e recebendo mensagens de erro ou um código de integração.

Também demonstra como consultar um dataset interno no fluig e como usar o campo de zoom para buscar dados de um dataset próprio.

## Processo de Solicitação de Compra de RM (solicitacao-compra-rm)

Este exemplo demonstra um fluxo de solicitação de compra no RM, passando por uma etapa de aprovação da solicitação por um grupo antes da efetivação de forma assíncrona da criação do registro.

Também demonstra como preencher a data atual e o código da solicitação em um campo de formulário, como fazer uma conexão para ao serviço do RM que disponibiliza acesso direto aos objetos de negócio (DataServer) e como efetivar dados no RM. E como gerenciar no formulário múltiplos campos de consulta a dataset, quando o item selecionado em um campo influencia nos filtros utilizados nos outros

## Processo de Ciência (publicacao-de-documento-iniciando-processo)

Este exemplo demonstra um fluxo de solicitação de ciência de um documento por usuários de um grupo, que é iniciada automaticamente após a publicação do documento, via evento global.