function afterDocumentPublisher(){
	const PASTA = 139;
	var documento = retornaDocumento();
	//Verifica se o tipo do documento é 2 (Veja documentType em https://tdn.totvs.com/display/public/fluig/Guia+de+propriedades+dos+objetos#Guiadepropriedadesdosobjetos-DocumentDto)
	//e verifica também se está sendo publicado na pasta cujo o id está contido na constante "PASTA"
	if(documento.documentoPai == PASTA && documento.tipo == 2){	
		log.info("Novo documento publicado na pasta " + PASTA);
		var dadosRequisicao = retornaDadosRequisicao(documento);
		try{
			//Inicializa o serviço
	        var servico = fluigAPI.getAuthorizeClientService();
			//Realiza a chamada do serviço e a variável "retorno" recebe a resposta da requisição
            var retorno = servico.invoke(JSON.stringify(dadosRequisicao));
			//Valida se o retorno da API é válido
            if(retorno.getResult() == null || retorno.getResult().isEmpty()){
            	 throw "Erro na inicialização do processo de ciência de publicação de documento. Favor contactar um administrador do sistema.";	    			 
            }
		} catch(e) {
			throw "Erro na inicialização do processo de ciência de publicação de documento: " + e;
	    }
	}
}

/**
 * Função para retornar os dados do documento
 */
function retornaDocumento() {
	var documento = getValue("WKDocument");
	return {
		codigo: documento.getDocumentId(),
		descricao: documento.getDocumentDescription(),
		tipo: documento.getDocumentType(),
		documentoPai: documento.getParentDocumentId(),
		versao: documento.getVersion(),
		tags: documento.getKeyWord(),
		comentarios: documento.getAdditionalComments(),
		descricaoVersaoRevisao: documento.getVersionDescription()
	};
}

/**
 * Função para retornar um objeto com os dados da requisição
 */
function retornaDadosRequisicao(documento) {
	//getValue("WKCompany") retorna o código da empresa cadastrada no fluig
	var empresa = getValue("WKCompany"); 
	var dadosUsuario = retornaDadosUsuario();
	//Endpoint do serviço que será consumido. Para mais informações acesse https://api.fluig.com/
	var endPoint = '/process-management/api/v2/processes/ciencia_publicacao_documento/start';
	return {                                                   
		companyId: "" + empresa, //Código da empresa
		serviceCode: "fluigAPI", //Código do serviço cadastrado no fluig. No fluig acesse o "Painel de Controle", depois "Serviços" para cadastrar um novo serviço
		endpoint: endPoint,  
		method: "post", // 'delete', 'patch', 'post', 'get'                                        
		timeoutService: "1000", // Tempo em milisegundos para o limite da resposta da integração
		params: {
			"targetState": 5, //Código da atividade no processo em que a solicitação será aberta
			"subProcessTargetState": 0, //Código da atividade do subprocesso, caso exista. Deixe como 0 se não houver subprocesso
			"comment": "Iniciado via publicação de documento.", //Comentário que irá aparecer na aba de complementos da solicitação aberta
			"formFields": {//Lista de campos que serão enviados na abertura da solicitação
				"dataSolicitacao": "" + retornaDataAtualFormatada(),
				"nomePublicador": "" + dadosUsuario.nome,
				"codigoPublicador": "" + dadosUsuario.matricula,
				"emailPublicador": "" + dadosUsuario.email,
				"codigoDocumento": "" + documento.codigo,
				"descricaoDocumento": ""+ documento.descricao,
				"versaoDocumento": "" + documento.versao,
				"tagsDocumento": "" + documento.tags,
				"comentarioDocumento": "" + documento.comentarios,
				"descricaoVersaoRevisao": "" + documento.descricaoVersaoRevisao,
			}
		}	                                
	};
}

/**
 * Função para buscar informações do usuário logado
 */
function retornaDadosUsuario() {
	var usuarioAtual = fluigAPI.getUserService().getCurrent();	
	return {
		matricula: usuarioAtual.getCode(),
		nome: usuarioAtual.getFullName(),
		email : usuarioAtual.getEmail()
	};
}

/**
 * Função para formatar a data atual no formato "dia/mês/ano"
 */
function retornaDataAtualFormatada() {
	var dataFormatada = new java.text.SimpleDateFormat("dd/MM/yyyy");
	return dataFormatada.format(new Date());
}
