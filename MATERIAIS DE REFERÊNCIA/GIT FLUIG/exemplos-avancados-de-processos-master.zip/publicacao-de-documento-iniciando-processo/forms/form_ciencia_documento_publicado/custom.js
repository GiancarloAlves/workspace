//Função executada no fim do carregamento do formulário
$("document").ready(function() {
	//Rotina para remover espaços em branco no início e fim dos campos
	$('input[type="text"]').change(function(){
	    this.value = $.trim(this.value);
    });
	init();
});

function init() {
	if(MODO == 'VIEW'){
		$(".btn_ocultar").addClass("fs-display-none");
	}
	if(ATIVIDADE == ABERTURA || ATIVIDADE == INICIO){
		limparFormulario("Esta solicitação possui abertura automática! Em caso de dúvidas, contatar equipe administrativa.");
	}	
}

//Limpa informações do formulário caso a solicitação esteja sendo aberta via navegador
function limparFormulario(msg){	
	$(".fluig-style-guide").empty();
	$(".fluig-style-guide").append('<div class="well well-lg fs-txt-center">' + msg + '</div>');
}

//Abre uma aba do navegador para visualizar o documento
function acessarDocumento(){
	let url_documento = parent.WCMAPI.tenantURI+"/ecmnavigation?app_ecm_navigation_doc="+$("#codigoDocumento").val();
	window.open(url_documento,"_blank");
}