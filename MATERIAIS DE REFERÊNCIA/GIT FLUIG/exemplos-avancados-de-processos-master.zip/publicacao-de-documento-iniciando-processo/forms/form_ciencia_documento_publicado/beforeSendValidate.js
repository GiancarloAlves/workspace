/**
 * Funcao executada no momento do envio da solicitação para a próxima atividade e
 * é utilizada para realizar validações do formulário
 * @param {*} numState Número da atividade atual
 * @param {*} nextState Número da próxima atividade
 */
var beforeSendValidate = function(numState, nextState) {
	//Valida se a solicitação está sendo aberta pelo navegador ao invés de ser aberta automaticamente a partir da
	//publicação de um documento no GED
	if(numState == ABERTURA || numState == INICIO) {
		throw ("Esta solicitação possui abertura automática! Em caso de dúvidas, contatar equipe administrativa.");
	}
	
	//Verifica de o documento foi visualizado para então poder encaminhar a solicitação para a próxima atividade
	if (numState == TOMAR_CIENCIA) {
		if(!verificarDocumentoVisualizado()){
			throw ("Solicitação só pode ser movimentada após acesso e leitura do documento!");
		}
	}
}

/**
 * Função que consulta quantidade de acessos ao documento e retorna se houve algum acesso
 * realizado pelo usuário logado
 */
function verificarDocumentoVisualizado(){
	let codigoDocumento = $("#codigoDocumento").val();
	let versaoDocumento = $("#versaoDocumento").val();
	let usuarioAcessouDocumento = false;
	
	$.ajax({
		async: false,
		type: "GET",
		dataType: "json",
		url: "/api/public/ecm/document/documentHitsByVersion/" + codigoDocumento + "/" + versaoDocumento,
		error : function(XMLHttpRequest, textStatus, errorThrown) {
	    	FLUIGC.toast({message : "Erro ao consultar dados do documento", type : "danger"});
		}, success : function (data, status, xhr) {
			//Busca na lista de usuário se o usuário logado (variável ID_USUARIO que foi criada no displayFields) visualizou o documento
			for(var i = 0; i < data.content.userList.length; i++){
				if(data.content.userList[i].colleagueId == ID_USUARIO)
					usuarioAcessouDocumento = true;
			}
	    }
	});
	return usuarioAcessouDocumento;
}