let ABERTURA = 0;
let INICIO = 4;
let TOMAR_CIENCIA = 5;
let FIM = 9;