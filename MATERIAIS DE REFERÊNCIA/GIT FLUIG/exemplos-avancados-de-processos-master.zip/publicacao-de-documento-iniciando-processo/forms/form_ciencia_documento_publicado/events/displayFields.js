function displayFields(form, customHTML) {
    //Mostra campos desabilitados
    form.setShowDisabledFields(true);

    //getValue("WKNumState") retorna código da empresa cadastrada no fluig
    var atividade = getValue("WKNumState");
    //form.getFormMode() retorna o modo atual do formulário, sendo:
    //ADD: indicando modo de inclusão.
    //MOD: indicando modo de edição.
    //VIEW: indicando modo de visualização.
    //NONE: indicando que não há comunicação com o formulário, por exemplo, ocorre no momento da validação dos campos do formulário onde este não está sendo apresentado.
    var modo = form.getFormMode();
    //getValue("WKUser") retorna a matrícula do usuário logado
	var id_usuario = getValue("WKUser");
	
    // customHTML.append realiza a injeção de javascript pelo evento de formulário displayFields
    customHTML.append("<script type='text/javascript'>");
    customHTML.append("let MODO = '" + modo + "';");
    customHTML.append("let ATIVIDADE = " + atividade + ";");
    customHTML.append("let ID_USUARIO = '" + id_usuario + "';");
    customHTML.append("</script>");
}