# Abertura de processo através de publicação de documento



## Caso de uso
Ao publicar um documento em uma pasta mapeada, um evento global inicia uma solicitação workflow para que um grupo de usuários tome ciência do documento que foi publicado. Nessta atividade, que está configurada com o mecanismo de atribuição por grupo de usuários, onde todos os usuários do grupo devem analisar os dados do documento publicado no formulário da solicitação e visualizar o documento para poder concluir a solicitação.

## Técnicas abordadas
- Criação de eventos globais (nesse desenvolvimento foi implementado o afterDocumentPublisher);
- Abertura de processos através da api fluig (/process-management/api/v2/processes/ciencia_publicacao_documento/start);
- Criação de um processo workflow;
- Criação de um formulário;
- Validações de formulário.

## Requisitos para o funcionamento do desenvolvimento
- Publicar o formulário form_ciencia_documento_publicado em uma pasta do GED;
- Cadastrar um grupo com o código `tomar-ciencia-documento` e adicionar os usuários responsáveis pela análise do documento. Case queira escolher outro código para o grupo, é necessário alterar no mecanismo de atribuição da atividade `Tomar Ciência` do processo;
- Cadastrar um serviço do tipo REST chamado `fluigAPI` no painel de controle tendo como domínio `http://<ENDERECO_FLUIG>:<PORTA>` e tipo de autenticação `Fluig API`.
- Publicar o processo ciencia_publicacao_documento.process;
- Alterar no evento global afterDocumentPublisher a pasta que será mapeada através da constante "const PASTA";