/**
 * Evento que será executado no momento da criação de uma nova solicitação
 * */
function afterProcessCreate(processId){
	//Adiciona no campo "codigoSolicitacao" o número da solicitação criada
	hAPI.setCardValue("codigoSolicitacao", processId);
}