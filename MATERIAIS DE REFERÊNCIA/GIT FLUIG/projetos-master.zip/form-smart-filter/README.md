# ﻿Smart Filter: como atualizar os dados de um campo zoom com valor preenchido em outro campo
---


Exemplo válido para versão 1.6.1 ou superior.

Neste exemplo veja como utilizar o método reloadZoomFilterValues em um formulário no fluig, para adicionar um filtro em um campo zoom com base no valor de outro campo do formulário. Baixe este projeto e veja como é fácil utilizar o método reloadZoomFilterValues utilizando JavaScript!

Para obter mais informações acesse [Desenvolvimento de Formulários](http://tdn.totvs.com/x/U4l8B). 